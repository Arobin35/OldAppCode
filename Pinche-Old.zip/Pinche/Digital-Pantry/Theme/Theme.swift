//
//  Untitled.swift
//  Digital-Pantry
//
//  Created by Abram Robin  on 6/18/25.
//
import SwiftUI

extension Color {
    static let pincheRed = Color(red: 217/255, green: 107/255, blue: 55/255)      // Terracotta
    static let pincheCream = Color(red: 241/255, green: 225/255, blue: 210/255) // #F1E1D2
    
    static let pincheCreamDarker = Color(red: 241/255, green: 229/255, blue: 217/255) // just slightly darker

    
    static let pincheText = Color(red: 75/255, green: 46/255, blue: 46/255)       // Rich brown
    static let pincheMuted = Color(red: 75/226, green: 46/232, blue: 46/206) //226, 232, 206
    static let pincheField = Color(red: 217/255, green: 180/255, blue: 140/255)
    static let pincheInput = Color(red: 240/255, green: 223/255, blue: 205/255) // #F0DFCD - warm almond
}

extension View {
    func cardStyle() -> some View {
        self
            .background(Color.pincheCream)
            .cornerRadius(12)
            .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }

    func primaryButtonStyle() -> some View {
        self
            .padding()
            .frame(maxWidth: .infinity)
            .background(Color.pincheRed)
            .foregroundColor(.white)
            .cornerRadius(12)
    }

    func sectionHeaderStyle() -> some View {
        self
            .font(.headline)
            .foregroundColor(.pincheRed)
            .padding(.leading)
    }
}
