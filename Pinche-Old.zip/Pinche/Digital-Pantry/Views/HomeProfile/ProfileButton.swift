import SwiftUI

struct ProfileButton: View {
    var body: some View {
        VStack {
            Image(systemName: "person.circle.fill")
                .font(.system(size: 20))
                .foregroundColor(.accentColor)
            Text("Profile")
                .font(.caption2)
                .foregroundColor(.primary)
        }
        .padding(.vertical, 4)
        .frame(width: 50, height: 50)
        .background(Color(.systemGray6))
        .cornerRadius(8)
        .shadow(radius: 3)
    }
}
