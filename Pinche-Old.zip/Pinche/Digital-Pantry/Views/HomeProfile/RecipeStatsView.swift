import SwiftUI

struct RecipeStatsView: View {
    @State private var recipes: [RecipeSummary] = []
    @State private var expandedRecipeID: Int?
    private let userID = UserDefaults.standard.string(forKey: "loggedInUserID") ?? ""

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Recipes")
                        .sectionHeaderStyle()

                    if recipes.isEmpty {
                        Text("No recipes found.")
                            .foregroundColor(.gray)
                            .padding()
                    } else {
                        ForEach(recipes) { recipe in
                            VStack(alignment: .leading, spacing: 8) {
                                Button(action: {
                                    withAnimation {
                                        expandedRecipeID = (expandedRecipeID == recipe.id) ? nil : recipe.id
                                    }
                                }) {
                                    HStack {
                                        Text(recipe.title)
                                            .font(.headline)
                                        Spacer()
                                        Image(systemName: expandedRecipeID == recipe.id ? "chevron.up" : "chevron.down")
                                    }
                                    .padding()
                                    .background(Color.white)
                                    .cornerRadius(8)
                                }

                                if expandedRecipeID == recipe.id {
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text("📅 Created: \(recipe.created_at)")
                                            .font(.caption)
                                            .foregroundColor(.secondary)

                                        Text("🧂 Ingredients:")
                                            .bold()
                                        Text(recipe.ingredients)
                                            .fixedSize(horizontal: false, vertical: true)

                                        Text("📖 Instructions:")
                                            .bold()
                                            .padding(.top, 4)
                                        Text(recipe.instructions)
                                            .fixedSize(horizontal: false, vertical: true)

                                        Button(role: .destructive) {
                                            deleteRecipe(recipeID: recipe.id)
                                        } label: {
                                            Label("Delete Recipe", systemImage: "trash")
                                        }
                                        .padding(.top)
                                    }
                                    .cardStyle()
                                    .padding(.bottom, 8)
                                    .background(Color.white)
                                    .cornerRadius(8)
                                }
                            }
                        }
                    }
                }
                .padding()
            }
            .background(Color.pincheCream)
            .navigationTitle("Saved Recipes")
            .onAppear(perform: fetchRecipes)
        }
    }

    private func fetchRecipes() {
        guard let url = URL(string: "http://127.0.0.1:8000/user_recipes/\(userID)") else {
            print("❌ Invalid URL")
            return
        }

        URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error {
                print("❌ Fetch error: \(error)")
                return
            }

            guard let data = data else {
                print("❌ No data received")
                return
            }

            do {
                let decoded = try JSONDecoder().decode([RecipeSummary].self, from: data)
                DispatchQueue.main.async {
                    self.recipes = decoded
                }
            } catch {
                print("❌ Decoding error: \(error)")
            }
        }.resume()
    }

    private func deleteRecipe(recipeID: Int) {
        guard let url = URL(string: "http://127.0.0.1:8000/recipes/\(recipeID)") else {
            print("❌ Invalid delete URL")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"

        URLSession.shared.dataTask(with: request) { _, response, error in
            if let error = error {
                print("❌ Delete error: \(error)")
                return
            }

            DispatchQueue.main.async {
                self.recipes.removeAll { $0.id == recipeID }
                self.expandedRecipeID = nil
            }
        }.resume()
    }
}
