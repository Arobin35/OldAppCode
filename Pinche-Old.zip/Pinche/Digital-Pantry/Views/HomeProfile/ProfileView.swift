import SwiftUI

struct ProfileView: View {
    @State private var username: String
    @State private var email: String
    @State private var phone: String
    @State private var profilePictureURL: String
    @State private var familyID: String
    @State private var isEditing = false

    var user: User

    init(user: User) {
        _username = State(initialValue: user.username)
        _email = State(initialValue: user.email ?? "")
        _phone = State(initialValue: user.phone ?? "")
        _profilePictureURL = State(initialValue: user.profilePicture ?? "")
        _familyID = State(initialValue: user.familyID ?? "")
        self.user = user
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    
                    // Profile Image
                    HStack {
                        Spacer()
                        if let url = URL(string: profilePictureURL), !profilePictureURL.isEmpty {
                            AsyncImage(url: url) { image in
                                image.resizable()
                                    .scaledToFill()
                                    .frame(width: 100, height: 100)
                                    .clipShape(Circle())
                            } placeholder: {
                                Image(systemName: "person.crop.circle.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 100, height: 100)
                                    .foregroundColor(.gray)
                            }
                        } else {
                            Image(systemName: "person.crop.circle.fill")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 100)
                                .foregroundColor(.gray)
                        }
                        Spacer()
                    }
                    .padding(.top)

                    // Personal Info
                    Text("Personal Information").sectionHeaderStyle()

                    VStack(spacing: 12) {
                        labeledField("Username", $username)
                        labeledField("Email", $email)
                        labeledField("Phone", $phone)
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)

                    // Family Info
                    Text("Family").sectionHeaderStyle()
                    VStack(spacing: 12) {
                        labeledField("Family ID", $familyID)
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)

                    // Stats Links
                    Text("Statistic Information").sectionHeaderStyle()
                    NavigationLink(destination: StatsView()) {
                        HStack {
                            Text("View My Stats")
                                .fontWeight(.bold)
                            Spacer()
                            Text("→")
                                .foregroundColor(.gray)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                    }

                    Text("All Saved Recipes").sectionHeaderStyle()
                    NavigationLink(destination: RecipeStatsView()) {
                        HStack {
                            Text("View My Saved Recipes")
                                .fontWeight(.bold)
                            Spacer()
                            Text("→")
                                .foregroundColor(.gray)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                    }

                }
                .padding()
            }
            .background(Color.pincheCream)
            .navigationTitle("Profile")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(isEditing ? "Confirm" : "Edit") {
                        if isEditing {
                            updateUserProfile()
                        }
                        isEditing.toggle()
                    }
                }
            }
            .navigationTitle("Profile")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(isEditing ? "Confirm" : "Edit") {
                        if isEditing {
                            updateUserProfile()
                        }
                        isEditing.toggle()
                    }
                }
            }
        }
        .background(Color.pincheCream)
    }

    private func updateUserProfile() {
        guard let userID = user.id else { return }

        let updatedUser = User(
            id: userID,
            username: username,
            email: email,
            phone: phone,
            passwordHash: user.passwordHash,
            profilePicture: profilePictureURL,
            familyID: familyID,
            createdAt: user.createdAt
        )

        APIClient.shared.updateUserProfile(updatedUser) { error in
            if let error = error {
                print("❌ Failed to update profile: \(error.localizedDescription)")
            } else {
                print("✅ Profile updated successfully")
                refreshUserProfile() // ✅ Pull latest data from backend
            }
        }
    }
    
    private func refreshUserProfile() {
        guard let userID = user.id else { return }

        APIClient.shared.fetchUserProfile(userID: String(userID)) { updatedUser, error in
            DispatchQueue.main.async {
                if let updatedUser = updatedUser {
                    self.username = updatedUser.username
                    self.email = updatedUser.email ?? ""
                    self.phone = updatedUser.phone ?? ""
                    self.profilePictureURL = updatedUser.profilePicture ?? ""
                    self.familyID = updatedUser.familyID ?? ""
                    print("🔁 Profile reloaded from server")
                } else {
                    print("❌ Failed to reload profile: \(error?.localizedDescription ?? "Unknown error")")
                }
            }
        }
    }
    
    @ViewBuilder
    private func labeledField(_ label: String, _ binding: Binding<String>) -> some View {
        HStack {
            Text(label)
                .fontWeight(.bold)
            Spacer()
            if isEditing {
                TextField(label, text: binding)
                    .padding(8)
                    .background(Color.pincheInput)
                    .cornerRadius(8)
                    .frame(maxWidth: 200)
                    .multilineTextAlignment(.trailing)
            } else {
                Text(binding.wrappedValue)
                    .foregroundColor(.gray)
            }
        }
    }
    
}


