import SwiftUI

struct UserCreateView: View {
    @State private var navigateToHomeAsGuest = false // ✅ Controls Guest Navigation

    var body: some View {
        NavigationStack {
            VStack(spacing: 40) {
                Spacer()
                // Logo or Icon
                Image("PincheLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 150, height: 150)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(radius: 4)
                
                // Buttons
                VStack(spacing: 20) {
                    NavigationLink(destination: SignInView()) {
                        Text("Sign In")
                            .primaryButtonStyle()
                    }
                    
                    NavigationLink(destination: NewUserView()) {
                        Text("Create New User")
                            .primaryButtonStyle()
                        //.background(Color.pincheMuted)
                    }
                    
                    Button(action: { navigateToHomeAsGuest = true }) {
                        Text("Continue as Guest")
                            .primaryButtonStyle()
                        //.background(Color.pincheMuted)
                    }
                }
                .padding(.horizontal, 40)
                Spacer()
            }
            
            .padding(.top, 30)
            .navigationTitle("Sign In Options")
            .navigationBarTitleDisplayMode(.inline)
            .background(Color.pincheCream.ignoresSafeArea())
            .navigationDestination(isPresented: $navigateToHomeAsGuest) {
                HomeView(user: User(username: "Guest", email: nil, phone: nil, passwordHash: "", profilePicture: nil, familyID: nil, createdAt: "\(Date())"))
            }
        }
    }
}

