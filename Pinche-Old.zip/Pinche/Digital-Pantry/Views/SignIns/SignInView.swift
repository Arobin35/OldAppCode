//
//  SignInView.swift
//  Digital-Pantry
//
//  Created by Abram Robin on 2/27/25.
//

import SwiftUI

struct SignInView: View {
    @State private var identifier: String = ""
    @State private var password: String = ""
    @State private var showPassword: Bool = false
    @State private var showAlert: Bool = false
    @State private var errorMessage: String = ""
    @State private var navigateToHome: Bool = false
    @State private var isLoading: Bool = false
    @State private var loggedInUser: User?

    var body: some View {
        NavigationStack {
            VStack(spacing: 30) {
                Spacer()
                Text("Sign In")
                    .font(.largeTitle.bold())
                    .foregroundColor(.pincheText)
                // ✅ Username Field
                TextField("Username or Email", text: $identifier)
                
                    .textInputAutocapitalization(.never)
                    .padding()
                    .background(Color.pincheField)
                    .cornerRadius(10)
                    .foregroundColor(.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.pincheText.opacity(0.1), lineWidth: 1)
                    )

                // ✅ Password Field with Visibility Toggle
                HStack {
                    Group {
                        if showPassword {
                            TextField("Password", text: $password)
                                .foregroundColor(.white)
                        } else {
                            SecureField("Password", text: $password)
                                .foregroundColor(.white)
                        }
                    }
                    Button(action: {
                        showPassword.toggle()
                    }) {
                        Image(systemName: showPassword ? "eye.slash.fill" : "eye.fill")
                            .foregroundColor(.pincheText)

                    }
                }
                    .foregroundColor(.pincheText)
                    .padding(.vertical, 12)
                    .padding(.horizontal)
                    .background(Color.pincheField)
                    .cornerRadius(10)

                    

                // ✅ Sign In Button
                Button(action: signInUser) {
                    if isLoading {
                        ProgressView()
                    } else {
                        Text("Sign In")
                            .primaryButtonStyle()
                    }
                }
                .disabled(isLoading)

                Spacer()
            }
            .padding()
            .background(Color.pincheCream.ignoresSafeArea())
            .navigationDestination(isPresented: $navigateToHome) {
                if let user = loggedInUser {
                    HomeView(user: user)
                } else {
                    Text("Error: User data missing.")
                        .font(.title)
                        .foregroundColor(.red)
                }
            }
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Sign In Failed"), message: Text(errorMessage), dismissButton: .default(Text("OK")))
            }
        }
    }

    // ✅ Sign-in logic
    private func signInUser() {
        isLoading = true

        APIClient.shared.verifyUserExists(identifier: identifier) { exists, error in
            DispatchQueue.main.async {
                if let error = error {
                    self.errorMessage = "Error verifying user: \(error)"
                    self.showAlert = true
                    self.isLoading = false
                    return
                }

                if exists {
                    APIClient.shared.fetchUserID(identifier: identifier) { userID, error in
                        DispatchQueue.main.async {
                            if let error = error {
                                self.errorMessage = "Failed to fetch user ID: \(error)"
                                self.showAlert = true
                                self.isLoading = false
                                return
                            }

                            guard let userID = userID else {
                                self.errorMessage = "User ID not found."
                                self.showAlert = true
                                self.isLoading = false
                                return
                            }

                            APIClient.shared.fetchUserProfile(userID: String(userID)) { user, error in
                                DispatchQueue.main.async {
                                    self.isLoading = false

                                    if let user = user, user.passwordHash == self.password {
                                        self.saveUserSession(user: user)
                                        self.loggedInUser = user
                                        self.navigateToHome = true
                                    } else {
                                        self.errorMessage = "Incorrect password. Please try again."
                                        self.showAlert = true
                                    }
                                }
                            }
                        }
                    }
                } else {
                    self.errorMessage = "Account not found. Please create an account to sign in."
                    self.showAlert = true
                    self.isLoading = false
                }
            }
        }
    }

//    private func saveUserSession(user: User) {
//        guard let userID = user.id else { return }
//        let userIDString = String(userID)
//        UserDefaults.standard.set(userIDString, forKey: "loggedInUserID")
//    }
//    
    private func saveUserSession(user: User) {
        guard let userID = user.id else { return }

        let userIDString = String(userID)
        UserDefaults.standard.set(userIDString, forKey: "loggedInUserID")

        // ✅ Save family ID
        UserDefaults.standard.set(user.familyID, forKey: "loggedInFamilyID")

        // ✅ Save full User object for later decoding
        if let encoded = try? JSONEncoder().encode(user) {
            UserDefaults.standard.set(encoded, forKey: "loggedInUserObject")
        }
    }

    private func getUserID() -> Int? {
        guard let userIDString = UserDefaults.standard.string(forKey: "loggedInUserID"),
              let userID = Int(userIDString) else {
            return nil
        }
        return userID
    }
}
