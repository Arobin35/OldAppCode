import SwiftUI

struct StatsView: View {
    @State private var stats: [WastedItemStat] = []
    @State private var editingIndex: Int?
    @State private var updatedCount: Int = 0
    private let userID = UserDefaults.standard.string(forKey: "loggedInUserID") ?? ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Most Wasted Items")
                    .sectionHeaderStyle() // ⬅️ Use your custom header style

                if stats.isEmpty {
                    Text("No data available.")
                        .foregroundColor(.gray)
                        .padding(.top)
                } else {
                    ForEach(stats.indices, id: \.self) { index in
                        let item = stats[index]

                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text("\(index + 1). \(item.name)")
                                    .fontWeight(.semibold)
                                    .foregroundColor(.pincheText)

                                Spacer()

                                Text("\(item.count) times")
                                    .foregroundColor(.secondary)
                            }

                            if editingIndex == index {
                                Stepper("Wasted: \(updatedCount)", value: $updatedCount, in: 0...100)

                                HStack {
                                    Button("Save") {
                                        APIClient.shared.updateWastedItem(itemName: item.name, userID: userID, quantity: updatedCount) { error in
                                            if error == nil {
                                                stats[index].count = updatedCount
                                                editingIndex = nil
                                            } else {
                                                print("❌ Update failed: \(error!.localizedDescription)")
                                            }
                                        }
                                    }

                                    Button("Cancel") {
                                        editingIndex = nil
                                    }
                                }
                                .padding(.top, 4)
                            } else {
                                HStack {
                                    Button("Edit") {
                                        editingIndex = index
                                        updatedCount = item.count
                                    }

                                    Button(role: .destructive) {
                                        APIClient.shared.deleteWastedItem(itemName: item.name, userID: userID) { error in
                                            if error == nil {
                                                stats.remove(at: index)
                                            } else {
                                                print("❌ Delete failed: \(error!.localizedDescription)")
                                            }
                                        }
                                    } label: {
                                        Image(systemName: "trash")
                                    }
                                }
                                .padding(.top, 4)
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(12)
                        .shadow(color: .black.opacity(0.05), radius: 3, x: 0, y: 2)
                        .padding(.bottom, 8)
                    }
                }

                Spacer()
            }
            .padding()
        }
        .background(Color.pincheCream) // ⬅️ Matches app theme
        .navigationTitle("Stats")
        .onAppear(perform: fetchStats)
    }

    private func fetchStats() {
        guard !userID.isEmpty else {
            print("❌ Missing user ID")
            return
        }

        APIClient.shared.fetchWastedStats(userID: userID) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let data):
                    self.stats = data
                case .failure(let error):
                    print("❌ Failed to fetch stats: \(error)")
                }
            }
        }
    }
}
