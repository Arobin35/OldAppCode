////
////  NewUserView.swift
////  Digital-Pantry
////
////  Created by Abram Robin on 2/27/25.
////
//
//import SwiftUI
//
//struct NewUserView: View {
//    @State private var name: String = ""
//    @State private var email: String = ""
//    @State private var phoneNumber: String = ""
//    @State private var password: String = ""
//    @State private var familyID: String = ""
//
//    @State private var errorMessage: String?
//    @State private var showErrorAlert: Bool = false
//    @State private var isSignedIn: Bool = false
//
//    var body: some View {
//        VStack(spacing: 15) {
//            Text("Create Account")
//                .font(.largeTitle)
//                .bold()
//                .padding(.top, 40)
//
//            // Name Field (Required)
//            VStack(alignment: .leading, spacing: 3) {
//                Text("Name *").bold()
//                TextField("Enter your name", text: $name)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                    .autocapitalization(.words)
//            }
//
//            // Email Field (Optional)
//            VStack(alignment: .leading, spacing: 3) {
//                Text("Email (Optional)").bold()
//                TextField("Enter your email", text: $email)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                    .keyboardType(.emailAddress)
//                    .autocapitalization(.none)
//            }
//
//            // Phone Number Field (Optional)
//            VStack(alignment: .leading, spacing: 3) {
//                Text("Phone Number (Optional)").bold()
//                TextField("Enter your phone number", text: $phoneNumber)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                    .keyboardType(.phonePad)
//            }
//
//            // Password Field (Required)
//            VStack(alignment: .leading, spacing: 3) {
//                Text("Password *").bold()
//                SecureField("Enter your password", text: $password)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                    .autocapitalization(.none)
//            }
//
//            // Family ID Field (Optional)
//            VStack(alignment: .leading, spacing: 3) {
//                Text("Family ID (Optional)").bold()
//                TextField("Enter family ID", text: $familyID)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                    .keyboardType(.numberPad)
//            }
//
//            // Sign Up Button
//            Button(action: createUser) {
//                Text("Sign Up")
//                    .frame(maxWidth: .infinity)
//                    .padding()
//                    .background(Color.blue)
//                    .foregroundColor(.white)
//                    .cornerRadius(10)
//            }
//            .padding(.top, 10)
//
//            Spacer()
//        }
//        .padding()
//        .alert(isPresented: $showErrorAlert) {
//            Alert(title: Text("Sign-Up Failed"), message: Text(errorMessage ?? "An error occurred"), dismissButton: .default(Text("OK")))
//        }
//        .fullScreenCover(isPresented: $isSignedIn) {
//            HomeView(user: User(
//                username: name,
//                email: email.isEmpty ? nil : email,
//                phone: phoneNumber.isEmpty ? nil : phoneNumber,
//                passwordHash: password,
//                familyID: familyID.isEmpty ? nil : familyID,
//                createdAt: ISO8601DateFormatter().string(from: Date())  // ✅ Fix missing argument
//            ))
//        }
//    }
//
//    // ✅ Function to create a new user
//    private func createUser() {
//        let formatter = ISO8601DateFormatter()
//        let createdAtString = formatter.string(from: Date())
//
//        guard !name.isEmpty else {
//            self.errorMessage = "Name is required."
//            self.showErrorAlert = true
//            return
//        }
//        guard !password.isEmpty else {
//            self.errorMessage = "Password is required."
//            self.showErrorAlert = true
//            return
//        }
//        
////        guard !familyID.isEmpty else {
////            self.errorMessage = "Family ID is required (EX: familyName####)."
////            self.showErrorAlert = true
////            return
////        }
//
//        let newUser = User(
//            username: name,
//            email: email.isEmpty ? nil : email,
//            phone: phoneNumber.isEmpty ? nil : phoneNumber,
//            passwordHash: password,
//            profilePicture: nil,
//            familyID: familyID.isEmpty ? nil : familyID,
//            createdAt: createdAtString
//        )
//
//        print("📡 Sending User Data: \(newUser)")  // ✅ Check if the data is correct before sending
//
//        APIClient.shared.addUser(newUser) { userID, error in
//            if let error = error {
//                self.errorMessage = error
//                self.showErrorAlert = true
//            } else if let userID = userID {
//                UserDefaults.standard.set(String(userID), forKey: "loggedInUserID")
//                UserDefaults.standard.set(familyID, forKey: "loggedInFamilyID")
//                print("✅ Stored userID: \(userID)")
//                self.isSignedIn = true
//            }
//        }
//    }
//
//}
//
import SwiftUI

struct NewUserView: View {
    @State private var name: String = ""
    @State private var email: String = ""
    @State private var phoneNumber: String = ""
    @State private var password: String = ""
    @State private var familyID: String = ""

    @State private var errorMessage: String?
    @State private var showErrorAlert: Bool = false
    @State private var isSignedIn: Bool = false

    var body: some View {
        VStack(spacing: 20) {
            Text("Create Account")
                .font(.largeTitle.bold())
                .foregroundColor(.pincheText)
                .padding(.top, 40)

            Group {
                customField(label: "Name *", placeholder: "Enter your name", text: $name)
                customField(label: "Email (Optional)", placeholder: "Enter your email", text: $email, keyboard: .emailAddress)
                customField(label: "Phone Number (Optional)", placeholder: "Enter your phone number", text: $phoneNumber, keyboard: .phonePad)
                customSecureField(label: "Password *", placeholder: "Enter your password", text: $password)
                customField(label: "Family ID (Optional)", placeholder: "Enter family ID", text: $familyID, keyboard: .numberPad)
            }

            Button(action: createUser) {
                Text("Sign Up")
                    .primaryButtonStyle()
            }
            .padding(.top, 10)

            Spacer()
        }
        .padding()
        .background(Color.pincheCream.ignoresSafeArea())
        .alert(isPresented: $showErrorAlert) {
            Alert(title: Text("Sign-Up Failed"), message: Text(errorMessage ?? "An error occurred"), dismissButton: .default(Text("OK")))
        }
        .fullScreenCover(isPresented: $isSignedIn) {
            HomeView(user: User(
                username: name,
                email: email.isEmpty ? nil : email,
                phone: phoneNumber.isEmpty ? nil : phoneNumber,
                passwordHash: password,
                familyID: familyID.isEmpty ? nil : familyID,
                createdAt: ISO8601DateFormatter().string(from: Date())
            ))
        }
    }

    private func customField(label: String, placeholder: String, text: Binding<String>, keyboard: UIKeyboardType = .default) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(label)
                .font(.subheadline)
                .foregroundColor(.pincheText)
            TextField("", text: text)
                .placeholder(when: text.wrappedValue.isEmpty) {
                    Text(placeholder).foregroundColor(.white.opacity(0.6))
                }
                .keyboardType(keyboard)
                .autocapitalization(.none)
                .padding()
                .background(Color.pincheField)
                .cornerRadius(10)
                .foregroundColor(.white)
        }
    }

    private func customSecureField(label: String, placeholder: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(label)
                .font(.subheadline)
                .foregroundColor(.pincheText)
            SecureField("", text: text)
                .placeholder(when: text.wrappedValue.isEmpty) {
                    Text(placeholder).foregroundColor(.white.opacity(0.6))
                }
                .padding()
                .background(Color.pincheField)
                .cornerRadius(10)
                .foregroundColor(.white)
        }
    }

    private func createUser() {
        let formatter = ISO8601DateFormatter()
        let createdAtString = formatter.string(from: Date())

        guard !name.isEmpty else {
            self.errorMessage = "Name is required."
            self.showErrorAlert = true
            return
        }
        guard !password.isEmpty else {
            self.errorMessage = "Password is required."
            self.showErrorAlert = true
            return
        }

        let newUser = User(
            username: name,
            email: email.isEmpty ? nil : email,
            phone: phoneNumber.isEmpty ? nil : phoneNumber,
            passwordHash: password,
            profilePicture: nil,
            familyID: familyID.isEmpty ? nil : familyID,
            createdAt: createdAtString
        )

        APIClient.shared.addUser(newUser) { userID, error in
            if let error = error {
                self.errorMessage = error
                self.showErrorAlert = true
            } else if let userID = userID {
                UserDefaults.standard.set(String(userID), forKey: "loggedInUserID")
                UserDefaults.standard.set(familyID, forKey: "loggedInFamilyID")
                self.isSignedIn = true
            }
        }
    }
}

// Placeholder support
extension View {
    func placeholder<Content: View>(
        when shouldShow: Bool,
        alignment: Alignment = .leading,
        @ViewBuilder placeholder: () -> Content
    ) -> some View {
        ZStack(alignment: alignment) {
            placeholder().opacity(shouldShow ? 1 : 0)
            self
        }
    }
}


