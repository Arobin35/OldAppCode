import SwiftUI

import SwiftUI

struct PreviewLauncherView: View {
    var body: some View {
        NavigationStack {
            VStack {
                Text("Welcome to Chef-Pal")
                    .font(.title)
                    .padding()
                
                NavigationLink(destination: UserCreateView()) {
                    Text("Enter App")
                        .font(.headline)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .padding(.horizontal)
                }
            }
        }
    }
}


struct PreviewLauncherView_Previews: PreviewProvider {
    static var previews: some View {
        PreviewLauncherView()
    }
}
