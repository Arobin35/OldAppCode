import SwiftUI
import AVFoundation

enum StorageLocation {
    case fridge
    case pantry
}

struct ScanView: View {
    @State private var scannedCode: String = ""
    @State private var productName: String?
    @State private var expirationDate: String?
    @State private var isShowingScanner = false
    @State private var selectedLocation: StorageLocation?
    @State private var hasScanned = false
    @State private var showConfirmation = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Spacer()
                Text("Scan a Barcode")
                    .font(.largeTitle.bold())
                    .foregroundColor(.pincheText)

                HStack(spacing: 20) {
                    Button("Add to Fridge") {
                        selectedLocation = .fridge
                        isShowingScanner = true
                    }
                    .padding()
                    .background(Color.pincheRed)
                    .foregroundColor(.white)
                    .cornerRadius(10)

                    Button("Add to Pantry") {
                        selectedLocation = .pantry
                        isShowingScanner = true
                    }
                    .padding()
                    .background(Color.pincheRed)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }

                if let productName = productName {
                    VStack(spacing: 5) {
                        Text("Product: \(productName)")
                            .font(.headline)
                            .foregroundColor(.pincheText)

                        if let expirationDate = expirationDate {
                            Text("Expires on: \(expirationDate)")
                                .foregroundColor(.red)
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(10)
                    .shadow(radius: 2)
                } else if !scannedCode.isEmpty {
                    Text("Looking up product info...")
                        .foregroundColor(.gray)
                }

                Spacer()
            }
            .padding()
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.pincheCream.ignoresSafeArea())
            .navigationTitle("Scan Item")
            .sheet(isPresented: $isShowingScanner, onDismiss: {
                hasScanned = false
            }) {
                BarcodeScannerView { scannedCode in
                    guard !hasScanned else { return }
                    hasScanned = true
                    self.scannedCode = scannedCode
                    self.fetchProductInfo(upc: scannedCode)
                    self.isShowingScanner = false
                }
            }
            .alert("Item Added!", isPresented: $showConfirmation) {
                Button("OK", role: .cancel) {}
            }
        }
    }

    private func fetchProductInfo(upc: String) {
        guard let url = URL(string: "https://world.openfoodfacts.org/api/v0/product/\(upc).json") else { return }

        let location = self.selectedLocation

        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                print("❌ Error fetching product: \(error?.localizedDescription ?? "Unknown error")")
                return
            }

            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let product = json["product"] as? [String: Any] {
                    DispatchQueue.main.async {
                        self.productName = product["product_name"] as? String ?? "Unknown"
                        self.expirationDate = product["expiration_date"] as? String

                        let formatter = DateFormatter()
                        formatter.dateFormat = "yyyy-MM-dd"
                        let defaultExpiration = Calendar.current.date(byAdding: .day, value: 7, to: Date())!
                        //let expirationString = self.expirationDate ?? formatter.string(from: defaultExpiration)
                        let expirationString: String
                        if let raw = self.expirationDate, !raw.isEmpty {
                            expirationString = raw
                        } else {
                            expirationString = formatter.string(from: defaultExpiration)
                        }

                        let userID = Int(UserDefaults.standard.string(forKey: "loggedInUserID") ?? "0") ?? 0

                        let item = FoodItem(
                            id: nil,
                            name: self.productName ?? "Unknown",
                            quantity: 1,
                            expiration_date: expirationString,
                            userID: userID
                        )


                        switch location {
                        case .fridge:
                            let encoder = JSONEncoder()
                            if let jsonData = try? encoder.encode(item),
                               let jsonString = String(data: jsonData, encoding: .utf8) {
                                print("📡 Sending POST request to \(url) with JSON payload: \(jsonString)")
                            }
                            APIClient.shared.addFridgeItem(item) { error in
                                print(error == nil ? "✅ Added to fridge" : "❌ Fridge error: \(error!)")
                                self.showConfirmation = (error == nil)
                            }
                        case .pantry:
                            APIClient.shared.addPantryItem(item) { error in
                                print(error == nil ? "✅ Added to pantry" : "❌ Pantry error: \(error!)")
                                self.showConfirmation = (error == nil)
                            }
                        case .none:
                            print("❌ No location selected.")
                        }
                    }
                }
            } catch {
                print("❌ JSON Parsing Error: \(error)")
            }
        }.resume()
    }
}

// ✅ Barcode Scanner Using AVCaptureSession
struct BarcodeScannerView: UIViewControllerRepresentable {
    var completion: (String) -> Void

    func makeCoordinator() -> Coordinator {
        return Coordinator(completion: completion)
    }

    func makeUIViewController(context: Context) -> ScannerViewController {
        let scannerVC = ScannerViewController()
        scannerVC.delegate = context.coordinator
        return scannerVC
    }

    func updateUIViewController(_ uiViewController: ScannerViewController, context: Context) {}

    class Coordinator: NSObject, AVCaptureMetadataOutputObjectsDelegate {
        var completion: (String) -> Void

        init(completion: @escaping (String) -> Void) {
            self.completion = completion
        }

        func metadataOutput(_ output: AVCaptureMetadataOutput,
                            didOutput metadataObjects: [AVMetadataObject],
                            from connection: AVCaptureConnection) {
            if let metadataObject = metadataObjects.first as? AVMetadataMachineReadableCodeObject,
               let barcode = metadataObject.stringValue {
                DispatchQueue.main.async {
                    self.completion(barcode)
                }
            }
        }
    }
}

// ✅ Actual Camera ViewController
class ScannerViewController: UIViewController {
    var captureSession: AVCaptureSession!
    var previewLayer: AVCaptureVideoPreviewLayer!
    var delegate: BarcodeScannerView.Coordinator?

    override func viewDidLoad() {
        super.viewDidLoad()

        captureSession = AVCaptureSession()

        guard let videoCaptureDevice = AVCaptureDevice.default(for: .video) else {
            showError(message: "No camera detected")
            return
        }

        do {
            let videoInput = try AVCaptureDeviceInput(device: videoCaptureDevice)
            if captureSession.canAddInput(videoInput) {
                captureSession.addInput(videoInput)
            } else {
                showError(message: "Could not add video input")
                return
            }
        } catch {
            showError(message: "Error accessing camera: \(error.localizedDescription)")
            return
        }

        let metadataOutput = AVCaptureMetadataOutput()
        if captureSession.canAddOutput(metadataOutput) {
            captureSession.addOutput(metadataOutput)
            metadataOutput.setMetadataObjectsDelegate(delegate, queue: DispatchQueue.main)
            metadataOutput.metadataObjectTypes = [.ean8, .ean13, .upce]
        } else {
            showError(message: "Could not add metadata output")
            return
        }

        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.frame = view.layer.bounds
        previewLayer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(previewLayer)

        DispatchQueue.global(qos: .userInitiated).async {
            self.captureSession.startRunning()
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        captureSession.stopRunning()
    }

    private func showError(message: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            self.present(alert, animated: true)
        }
    }
}
