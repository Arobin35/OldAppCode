import SwiftUI

struct AddFoodItemView: View {
    @State private var name: String = ""
    @State private var expirationDate = Date()
    @State private var quantity: String = ""
    var onAdd: (FoodItem) -> Void

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Item Details").foregroundColor(.pincheRed)) {
                    TextField("Item Name", text: $name)
                        .padding(8)
                        //.background(Color.pincheInput)
                        .cornerRadius(8)
                        .foregroundColor(.pincheText)

                    DatePicker("Expiration Date", selection: $expirationDate, displayedComponents: .date)
                        .accentColor(.pincheRed)
                        .foregroundColor(.pincheText)

                    TextField("Quantity", text: $quantity)
                        .keyboardType(.numberPad)
                        .padding(8)
                        //.background(Color.pincheInput)
                        .cornerRadius(8)
                        .foregroundColor(.pincheText)
                }

                Button(action: {
                    guard let quantityInt = Int(quantity), !name.isEmpty else { return }

                    let formatter = DateFormatter()
                    formatter.dateFormat = "yyyy-MM-dd"
                    let formattedDate = formatter.string(from: expirationDate)

                    let newItem = FoodItem(
                        id: nil,
                        name: name,
                        quantity: quantityInt,
                        expiration_date: formattedDate,
                        userID: Int(UserDefaults.standard.string(forKey: "loggedInUserID")!) ?? 0
                    )

                    print("✅ Adding new item: \(newItem)")
                    onAdd(newItem)
                }) {
                    Text("Add Item")
                        .bold()
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.pincheRed)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            }
            .scrollContentBackground(.hidden) // 👈 Remove default gray
            .background(Color.pincheCream)    // 👈 Add custom background
            .navigationTitle("Add Food Item")
        }
    }
}
