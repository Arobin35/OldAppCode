import SwiftUI

struct PantryView: View {
    @State private var pantryItems: [FoodItem] = []
    @State private var searchQuery: String = ""
    @State private var editingItemID: Int?
    @State private var editedItem: FoodItem?
    @State private var selectedItems: Set<Int> = []
    @State private var isDeleting: Bool = false
    @State private var isLoadingMore = false
    @State private var page = 1 // Supports infinite scrolling
    @State private var isAddingItem: Bool = false
    @State private var isDataLoaded = false // ✅ Tracks when data is first loaded

    
    @State private var showWastedAlert = false
    @State private var wastedItemName = ""
    
    
    
    private let userID: String? = UserDefaults.standard.string(forKey: "loggedInUserID")
    
    var body: some View {
        //NavigationView {
            VStack {
                searchBar
                
                ScrollView {
                    VStack(spacing: 5) { // ✅ Standard VStack instead of LazyVStack
                        ForEach(sortedFilteredItems) { item in
                            itemRow(item)
                                .id(item.id)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 2)
                        }
                    }
                    .padding(.top, 5)
                    .onAppear {
                        addInfiniteScrollTrigger() // ✅ Ensures infinite scrolling works
                    }
                }
                
                addItemButton
            }
            .background(Color.pincheCream) // 🔸 Add this line
            .navigationTitle("Pantry Items")
            .toolbar { deleteToolbar }
            .navigationViewStyle(.stack)
        
        //}
        .alert(isPresented: $showWastedAlert) {
            Alert(
                title: Text("Wasted!"),
                message: Text("\"\(wastedItemName)\" was successfully marked as wasted."),
                dismissButton: .default(Text("OK"))
            )
        }
    }
    
    // ✅ Search Bar Component
    private var searchBar: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
            
            TextField("Search for an item...", text: $searchQuery)
                .textFieldStyle(PlainTextFieldStyle())
                .onChange(of: searchQuery) { fetchItems() }
 // ✅ Live search
        }
        .padding(10)
        .background(Color.pincheField)
        .foregroundColor(.pincheText)
        .cornerRadius(10)
        .padding(.horizontal)
    }
    
    // ✅ Item Row
    private func itemRow(_ item: FoodItem) -> some View {
        HStack {
            if editingItemID == item.id {
                editModeView(for: item)
            } else {
                displayModeView(for: item)
            }
            
            Spacer()
            
            if !isDeleting {
                editButton(for: item)
                
                wasteButton(for: item)
            } else {
                deleteSelectionButton(for: item)
            }
        }
        .padding()
        .background(Color.white)
        .foregroundColor(.pincheText)
        .cornerRadius(10)
        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
            Button(role: .destructive) {
                markItemAsWasted(item)
            } label: {
                Label("Waste", systemImage: "trash.slash.fill")
            }
        }
    }
    
    




    
    // ✅ Edit Mode View
    private func editModeView(for item: FoodItem) -> some View {
        VStack(alignment: .leading) {
            Text("\(item.name)")
                .font(.headline)
                .foregroundColor(.gray)
            
            quantityAdjustmentView(for: item)
            
            DatePicker(
                "Expires:",
                selection: Binding(
                    get: { formattedDate(from: item.expiration_date) },
                    set: { newValue in
                        let formatter = DateFormatter()
                        formatter.dateFormat = "yyyy-MM-dd"
                        editedItem?.expiration_date = formatter.string(from: newValue)
                    }
                ),
                displayedComponents: .date
            )
            
            HStack {
                Button(action: { cancelEdit() }) {
                    Text("Cancel").foregroundColor(.red)
                }
                Spacer()
                Button(action: { confirmEdit(for: item) }) {
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                        Text("Confirm")
                    }
                    .foregroundColor(.blue)
                }
            }
        }
        .padding()
        .background(Color.pincheCreamDarker)
        .cornerRadius(10)
    }
    
    // ✅ Display Mode View
    private func displayModeView(for item: FoodItem) -> some View {
        VStack(alignment: .leading) { // ✅ Add spacing to match edit mode
            Text(item.name).font(.headline)
            Text("Quantity: \(item.quantity)").font(.subheadline)
            Text("Expires: \(item.expiration_date)").font(.subheadline).foregroundColor(.gray)
        }
        .padding() // ✅ Ensures same spacing as editModeView
        .background(Color(.systemGray6)) // ✅ Matches edit mode background
        .cornerRadius(10) // ✅ Ensures consistency in rounded corners
    }

    
    // ✅ Edit Button
    private func editButton(for item: FoodItem) -> some View {
        Button(action: {
            editingItemID = item.id
            editedItem = item
        }) {
            Image(systemName: "pencil")
                .resizable()
                .frame(width: 24, height: 24)
                .foregroundColor(.blue)
        }
        .contentShape(Rectangle())
    }
    
    // ✅ Quantity Adjustment View
    private func quantityAdjustmentView(for item: FoodItem) -> some View {
        HStack(spacing: 30) {
            Button(action: { updateQuantity(for: item, by: -1) }) {
                Image(systemName: "minus.circle.fill")
                    .resizable()
                    .frame(width: 40, height: 40)
                    .foregroundColor(.red)
            }

            Text("\(item.quantity)").font(.headline)

            Button(action: { updateQuantity(for: item, by: 1) }) {
                Image(systemName: "plus.circle.fill")
                    .resizable()
                    .frame(width: 40, height: 40)
                    .foregroundColor(.green)
            }
        }
        .padding(.vertical, 5)
    }

    
    // ✅ Delete Selection Button
    private func deleteSelectionButton(for item: FoodItem) -> some View {
        Button(action: { toggleSelection(item.id!) }) {
            Image(systemName: selectedItems.contains(item.id!) ? "checkmark.circle.fill" : "circle")
                .foregroundColor(selectedItems.contains(item.id!) ? .red : .gray)
        }
    }
    
    // ✅ Add Item Button
    private var addItemButton: some View {
        Button(action: {
            print("➕ Add Item button pressed!") // Debugging
            isAddingItem = true
        }) {
            HStack {
                Image(systemName: "plus.circle.fill")
                Text("Add Pantry Item")
            }
            .foregroundColor(.white)
            .padding()
            .background(Color.pincheRed)
            .cornerRadius(10)
        }
        .sheet(isPresented: $isAddingItem) { // ✅ This opens the add item form
            AddFoodItemView { newItem in
                addItem(newItem) // ✅ Calls the add function
                isAddingItem = false // ✅ Closes the sheet after adding
            }
        }
    }
    
    
    private func addItem(_ newItem: FoodItem) {
        APIClient.shared.addPantryItem(newItem) { error in
            if let error = error {
                print("❌ Failed to add item: \(error.localizedDescription)")
            } else {
                print("✅ Successfully added item: \(newItem.name)")
                DispatchQueue.main.async {
                    self.pantryItems.append(newItem) // ✅ Updates UI immediately
                    self.fetchItems() // ✅ Fetch latest items from API
                }
            }
        }
    }


    
    // ✅ Delete Toolbar
    private var deleteToolbar: some ToolbarContent {
        ToolbarItem(placement: .navigationBarTrailing) {
            Button(action: {
                withAnimation {
                    deleteSelectedItems()
                    isDeleting.toggle()
                }
            }) {
                Text(isDeleting ? "Confirm Delete" : "Delete")
                    .foregroundColor(isDeleting ? .red : .blue)
            }
        }
    }
    
    // ✅ Helper Functions
    private var sortedFilteredItems: [FoodItem] {
        pantryItems
            .filter { searchQuery.isEmpty || $0.name.lowercased().contains(searchQuery.lowercased()) }
            .sorted { $0.name < $1.name }
    }
    
    private func updateQuantity(for item: FoodItem, by amount: Int) {
        guard let index = pantryItems.firstIndex(where: { $0.id == item.id }) else { return }
        
        var updatedItem = pantryItems[index]
        updatedItem.quantity += amount // ✅ Modify quantity immediately

        // Prevent negative values
        if updatedItem.quantity < 0 {
            updatedItem.quantity = 0
        }

        print("📡 Updating item \(updatedItem.name) to quantity \(updatedItem.quantity)") // Debugging

        // ✅ Update UI immediately
        DispatchQueue.main.async {
            self.pantryItems[index].quantity = updatedItem.quantity
            self.editedItem = updatedItem // ✅ Ensure editedItem is also updated immediately
        }

        // ✅ Send update to API in the background
        APIClient.shared.updatePantryItem(updatedItem, userID: userID!) { _ in
            DispatchQueue.main.async {
                self.fetchItems() // ✅ Ensure latest data from API
            }
        }
    }




    
    private func formattedDate(from dateString: String) -> Date {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.date(from: dateString) ?? Date()
    }

    


    private func fetchItems() {
        APIClient.shared.fetchPantryItems(userID: userID!) { items, _ in
            DispatchQueue.main.async {
                if let newItems = items {
                    self.pantryItems = newItems // ✅ Completely replaces instead of appending
                }
            }
        }
    }


    
    private func deleteSelectedItems() {
        selectedItems.forEach { id in
            if let itemToDelete = pantryItems.first(where: { $0.id == id }) {
                APIClient.shared.deletePantryItem(name: itemToDelete.name, userID: userID!) { _ in fetchItems() }
            }
        }
    }
        
        private func addInfiniteScrollTrigger() {
            DispatchQueue.main.async {
                isLoadingMore = true
                page += 1
                APIClient.shared.fetchPantryItems(userID: userID!) { items, _ in
                    DispatchQueue.main.async {
                        if let newItems = items, !newItems.isEmpty {
                            pantryItems.append(contentsOf: newItems) // ✅ Append new items
                        }
                        isLoadingMore = false
                    }
                }
            }
        }
        
        
        private func cancelEdit() {
            editingItemID = nil
            editedItem = nil
        }
        
    private func confirmEdit(for item: FoodItem) {
        guard let index = pantryItems.firstIndex(where: { $0.id == item.id }) else { return }

        var updatedItem = pantryItems[index]

        // ✅ Use the updated expiration date from the binding
        if let newExpirationDate = editedItem?.expiration_date {
            updatedItem.expiration_date = newExpirationDate
        }

        // ✅ Ensure quantity is also updated
        updatedItem.quantity = editedItem?.quantity ?? updatedItem.quantity

        print("📡 Confirming update for \(updatedItem.name) with new expiration date: \(updatedItem.expiration_date)") // Debugging

        // ✅ Update UI immediately
        DispatchQueue.main.async {
            self.pantryItems[index] = updatedItem
            self.editingItemID = nil
            self.editedItem = nil
        }

        // ✅ Send the update to API
        APIClient.shared.updatePantryItem(updatedItem, userID: userID!) { _ in
            DispatchQueue.main.async {
                self.fetchItems() // ✅ Ensure fresh data from API after local update
            }
        }
    }




        
        private func toggleSelection(_ id: Int) {
            if selectedItems.contains(id) {
                selectedItems.remove(id)
            } else {
                selectedItems.insert(id)
            }
        }
    
    
    private func markItemAsWasted(_ item: FoodItem) {
        guard let userID = userID else { return }

        APIClient.shared.markPantryItemAsWasted(item: item, userID: userID) { error in
            DispatchQueue.main.async {
                if let error = error {
                    print("❌ Failed to mark as wasted: \(error.localizedDescription)")
                } else {
                    print("✅ Wasted item recorded. Deleting from Pantry.")
                    self.wastedItemName = item.name
                    self.showWastedAlert = true // ✅ Trigger the alert
                    APIClient.shared.deletePantryItem(name: item.name, userID: userID) { _ in
                        fetchItems()
                    }
                }
            }
        }
    }
    
        
    
    private func wasteButton(for item: FoodItem) -> some View {
        Button(action: {
            markItemAsWasted(item)
        }) {
            Image(systemName: "trash.slash.fill")
                .resizable()
                .frame(width: 24, height: 24)
                .foregroundColor(.orange)
                .padding(.leading, 8)
        }
        .contentShape(Rectangle())
        .help("Mark as Wasted")
    }
    
    
   
    
    
        
}
    

