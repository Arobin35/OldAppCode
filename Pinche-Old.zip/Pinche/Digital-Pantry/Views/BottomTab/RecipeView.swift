//
//  RecipesView.swift
//  Digital-Pantry
//
//  Created by Abram Robin on 1/26/25.
//

import SwiftUI

//struct Recipe: Identifiable, Codable, Equatable {
//    var id = UUID() // Unique identifier for SwiftUI List
//    var title: String
//    var ingredients: [String]
//    var instructions: String
//}

struct Recipe: Identifiable, Codable, Equatable {
    var id = UUID() // This is still local — backend will generate its own ID
    var title: String
    var ingredients: [String]
    var instructions: String

    // Optional future support:
    var rating: Int? = nil
    var nutritionInfo: String? = nil

    // Convert ingredients array into one string to match the backend API
    var ingredientsText: String {
        ingredients.joined(separator: "\n")
    }
}

struct RecipesView: View {
    @State private var generatedRecipe: Recipe? // Store the newly fetched recipe
    @State private var savedRecipes: [Recipe] = [] // Store saved recipes
    @State private var isLoading = false // Track loading state
    @State private var expandedRecipe: UUID? // Track which recipe is expanded
    @State private var userNotes: String = "" // 🔹 User-provided preferences or allergies

    let savedRecipesKey = "savedRecipes"

    var body: some View {
        //NavigationView {
            VStack {
                if isLoading {
                    ProgressView("Loading Recipe...")
                } else {
                    List {
                        // Display saved recipes as buttons
                        Section(header: Text("Saved Recipes").foregroundColor(.pincheRed)) {
                            if savedRecipes.isEmpty {
                                Text("No saved recipes yet.")
                                    .foregroundColor(.gray)
                            } else {
                                ForEach(savedRecipes) { recipe in
                                    Button(action: {
                                        withAnimation {
                                            expandedRecipe = (expandedRecipe == recipe.id) ? nil : recipe.id
                                        }
                                    }) {
                                        HStack {
                                            Text(recipe.title)
                                                .font(.headline)
                                                .foregroundColor(Color.pincheText)
                                            Spacer()
                                            Image(systemName: expandedRecipe == recipe.id ? "chevron.up" : "chevron.down")
                                                .foregroundColor(.gray)
                                        }
                                    }
                                    .padding()

                                    if expandedRecipe == recipe.id {
                                        RecipeDetailView(recipe: recipe)
                                    }
                                }
                                .onDelete(perform: deleteRecipe) // Swipe to delete
                            }
                        }

                        // Display the newly generated recipe
                        if let recipe = generatedRecipe {
                            Section(header: Text("New Recipe").foregroundColor(.pincheRed)) {
                                HStack {
                                    Text(recipe.title)
                                        .font(.headline)
                                        .padding(.vertical, 10)

                                    Spacer()

                                    Button(action: {
                                        toggleSaveRecipe(recipe)
                                    }) {
                                        Image(systemName: isRecipeSaved(recipe) ? "bookmark.fill" : "bookmark")
                                            .foregroundColor(isRecipeSaved(recipe) ? .blue : .gray)
                                    }
                                    .padding(.trailing, 10)
                                }

                                RecipeDetailView(recipe: recipe)
                            }
                        }
                    }
                    .listRowBackground(Color.pincheCream)
                    .scrollContentBackground(.hidden) // hides default background
                    .background(Color.pincheCream)
                }
                
                Text("Notes for the recipe. EX: Allergies, Italian inspired, No eggs, etc...")
                    .font(.subheadline)
                    .padding(.horizontal)

                TextEditor(text: $userNotes)
                    .frame(height: 80)
                    .padding()
                    .background(Color.pincheField)
                    .cornerRadius(10)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray.opacity(0.3)))
                    .padding(.horizontal)

                // "Generate New Recipe" button at the bottom
                Button(action: {
                    userNotes = ""
                    fetchRecipe()
                }) {
                    Text("Generate New Recipe")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.pincheRed)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .padding(.horizontal)
                }
            }
            .background(Color.pincheCream.ignoresSafeArea())
            .navigationTitle("Recipes")
            .onAppear {
                loadSavedRecipes() // Load saved recipes
                //UserDefaults.standard.removeObject(forKey: "savedRecipes")
            }
        //}
    }

    func fetchRecipe() {
        guard let userID = UserDefaults.standard.string(forKey: "loggedInUserID") else {
            print("❌ No user ID found.")
            return
        }

        isLoading = true

            APIClient.shared.makeRecipe(userID: userID, notes: userNotes) { recipeText, error in
            DispatchQueue.main.async {
                self.isLoading = false
                if let recipeText = recipeText {
                    let lines = recipeText.components(separatedBy: "\n").filter { !$0.isEmpty }
                    let title = lines.first ?? "Untitled Recipe"
                    let instructionsStart = lines.firstIndex(where: { $0.contains("Instructions") }) ?? lines.count
                    let ingredients = Array(lines[1..<instructionsStart])
                    let instructions = lines[instructionsStart...].joined(separator: "\n")
                    self.generatedRecipe = Recipe(title: title, ingredients: ingredients, instructions: instructions)
                } else {
                    print("❌ Recipe generation failed: \(error?.localizedDescription ?? "Unknown error")")
                }
            }
        }
    }

    func toggleSaveRecipe(_ recipe: Recipe) {
        if isRecipeSaved(recipe) {
            savedRecipes.removeAll { $0.id == recipe.id }
        } else {
            savedRecipes.append(recipe)
            saveRecipeToBackend(recipe) // ✅ <-- Save to server!
        }
    }

    func isRecipeSaved(_ recipe: Recipe) -> Bool {
        return savedRecipes.contains(where: { $0.id == recipe.id })
    }

    func deleteRecipe(at offsets: IndexSet) {
        for index in offsets {
            let recipe = savedRecipes[index]
            deleteRecipeFromBackend(recipe) // ✅ Remove from server
        }
        savedRecipes.remove(atOffsets: offsets)
    
    }


    func loadSavedRecipes() {
        guard let userID = UserDefaults.standard.string(forKey: "loggedInUserID") else {
            print("❌ No user ID found.")
            return
        }

        APIClient.shared.fetchUserRecipes(userID: userID) { recipes, error in
            DispatchQueue.main.async {
                if let recipes = recipes {
                    self.savedRecipes = recipes
                    print("✅ Loaded \(recipes.count) user recipes")
                } else {
                    print("❌ Failed to fetch user recipes: \(error?.localizedDescription ?? "Unknown error")")
                }
            }
        }
    }
    
    func saveRecipeToBackend(_ recipe: Recipe) {
        guard let userID = UserDefaults.standard.string(forKey: "loggedInUserID") else {
            print("❌ No user ID found.")
            return
        }

        guard let url = URL(string: "http://127.0.0.1:8000/save_recipe") else {
            print("❌ Invalid URL.")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload: [String: Any] = [
            "user_id": userID,
            "title": recipe.title,
            "ingredients": recipe.ingredientsText,
            "instructions": recipe.instructions,
            "rating": recipe.rating ?? 0,
            "nutrition_info": recipe.nutritionInfo ?? ""
        ]

        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: payload)
        } catch {
            print("❌ Failed to encode recipe payload: \(error)")
            return
        }

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("❌ Failed to save recipe: \(error.localizedDescription)")
            } else {
                print("✅ Recipe saved to backend.")
            }
        }.resume()
    }
    
    func deleteRecipeFromBackend(_ recipe: Recipe) {
        guard let userID = UserDefaults.standard.string(forKey: "loggedInUserID") else {
            print("❌ No user ID found.")
            return
        }

        let encodedTitle = recipe.title.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? ""
        guard let url = URL(string: "http://127.0.0.1:8000/recipes/\(encodedTitle)/\(userID)") else {
            print("❌ Invalid delete URL.")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"

        URLSession.shared.dataTask(with: request) { _, response, error in
            if let error = error {
                print("❌ Failed to delete recipe from backend: \(error.localizedDescription)")
            } else {
                print("✅ Recipe deleted from backend.")
            }
        }.resume()
    }
    
    
    
}

// Subview for displaying the full recipe details
import SwiftUI

struct RecipeDetailView: View {
    var recipe: Recipe

    var body: some View {
        ScrollView { // ✅ Enables Scrolling for Long Recipes
            VStack(alignment: .leading, spacing: 10) {
                Text(recipe.title) // ✅ Displays Recipe Name
                    .font(.title)
                    .fontWeight(.bold)
                    .padding(.bottom, 10)

                Text("Ingredients:")
                    .font(.headline)
                    .padding(.top, 10)

                ForEach(recipe.ingredients, id: \.self) { ingredient in
                    Text("• \(ingredient)")
                }

                Text("Instructions:")
                    .font(.headline)
                    .padding(.top, 10)

                Text(recipe.instructions)
                    .padding(.bottom, 10)
            }
            .padding()
        }
    }
}
