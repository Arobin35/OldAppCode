//
//  ListView.swift
//  Digital-Pantry
//
//  Created by Abram Robin  on 3/26/25.
//
//


import SwiftUI
struct ListView: View {
    @State private var isDeletingItem = false
    @State private var reloadTrigger = false
    @State private var isSubmittingItem = false
    @State private var isAddingItem = false
    @State private var newItemName = ""
    @State private var newItemNote = ""
    @State private var sharedItems: [SharedListItem] = []
    @State private var selectedItems: Set<Int> = []
    @State private var isDeleting: Bool = false
    @State private var searchQuery: String = ""
    
    private var user: User {
        // Load from your stored session (modify as needed)
        if //let userID = UserDefaults.standard.string(forKey: "loggedInUserID"),
            let userData = UserDefaults.standard.data(forKey: "loggedInUserObject"),
            let user = try? JSONDecoder().decode(User.self, from: userData) {
            return user
        }
        return User(id: 0, username: "Guest", email: nil, phone: nil, passwordHash: "", profilePicture: nil, familyID: nil, createdAt: "")
    }
    
    var filteredItems: [SharedListItem] {
        if searchQuery.isEmpty {
            return sharedItems
        } else {
            return sharedItems.filter { $0.name.lowercased().contains(searchQuery.lowercased()) }
        }
    }
    
    var body: some View {
        //NavigationView {
            VStack {
                // Search Bar
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.gray)
                    TextField("Search items...", text: $searchQuery)
                        .textFieldStyle(PlainTextFieldStyle())
                        .foregroundColor(.pincheText)
                }
                .padding(10)
                .background(Color.pincheField)
                .cornerRadius(10)
                .padding()
                
                List(filteredItems) { item in
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(item.name)
                                .font(.headline)
                                .foregroundColor(.pincheText)

                            if let notes = item.notes {
                                Text(notes)
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                        }

                        Spacer()

                        if isDeleting, let itemID = item.id {
                            Button(action: {
                                toggleSelection(itemID)
                            }) {
                                Image(systemName: selectedItems.contains(itemID) ? "checkmark.circle.fill" : "circle")
                                    .foregroundColor(selectedItems.contains(itemID) ? .red : .gray)
                            }
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(10)
                    .listRowSeparator(.hidden) // 🔹 Hide default separator
                    .listRowBackground(Color.clear) // 🔹 Prevent background override
                    .padding(.vertical, 2) // 🔹 Adds space between rows
                }
                .listStyle(PlainListStyle()) // ✅ Keeps layout clean
                .background(Color.pincheCream) // 👈 Fixes List background
            //}
            .navigationTitle("Shared List")
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Button(action: {
                        if isDeleting {
                            confirmDelete()
                            isDeletingItem = true
                        }
                        isDeleting.toggle()
                    }) {
                        Text(isDeleting ? "Confirm Delete" : "Delete")
                            .foregroundColor(isDeleting ? .red : .blue)
                    }
                    
                    Button(action: {
                        isAddingItem = true
                    }) {
                        Image(systemName: "plus")
                    }
                }
            }
            .onAppear {
                loadSharedItems()
            }

            .onChange(of: isAddingItem) {
                if !isAddingItem {
                    loadSharedItems()
                }
            }
            .onChange(of: isDeletingItem) {
                if !isAddingItem {
                    loadSharedItems()
                }
            }

           

            .sheet(isPresented: $isAddingItem) {
                NavigationView {
                    Form {
                        Section(header: Text("Item Details")) {
                            TextField("Item name", text: $newItemName)
                                .padding(8)
                                .background(Color.pincheInput)
                                .cornerRadius(8)
                            TextField("Notes (optional)", text: $newItemNote)
                                .padding(8)
                                .background(Color.pincheInput)
                                .cornerRadius(8)
                        }
                        
                        Button("Add Item") {
                            addNewItem()
                        }
                        .disabled(newItemName.isEmpty || isSubmittingItem)
                    }
                    .navigationTitle("New List Item")
                    .navigationBarItems(leading: Button("Cancel") {
                        isAddingItem = false
                        newItemName = ""
                        newItemNote = ""
                    })
                }
            }
        }
            .background(Color.pincheCream) // 🔹 Add this to match app theme
    }
    
    
    
    private func loadSharedItems() {
        APIClient.shared.fetchSharedListItems { items, error in
            DispatchQueue.main.async {
                if let error = error {
                    print("❌ Error fetching list: \(error.localizedDescription)")
                    return
                }

                if let items = items {
                    self.sharedItems = items
                }
            }
        }
    }
    
    
    private func toggleSelection(_ id: Int) {
        if selectedItems.contains(id) {
            selectedItems.remove(id)
        } else {
            selectedItems.insert(id)
        }
    }
    
    private func confirmDelete() {
        for id in selectedItems {
            APIClient.shared.deleteSharedListItem(id: id) { error in
                if let error = error {
                    print("❌ Failed to delete: \(error.localizedDescription)")
                } else {
                    print("✅ Deleted item successfully")
                }
            }
            
        }
        selectedItems.removeAll()
    }
    
    
    private func addNewItem() {
        guard let userIDString = UserDefaults.standard.string(forKey: "loggedInUserID"),
              let userID = Int(userIDString) else {
            print("❌ Missing user ID")
            return
        }

        let familyID = UserDefaults.standard.string(forKey: "loggedInFamilyID")
        print("👨‍👩‍👧‍👦 Family ID from defaults: \(familyID ?? "nil")")
        if familyID == nil {
            print("⚠️ No family ID found, falling back to user-only list")
        }

        let timestamp = ISO8601DateFormatter().string(from: Date())

        let item = SharedListItem(
            name: newItemName,
            family_id: familyID,
            added_by_user_id: userID,
            timestamp: timestamp,
            notes: newItemNote.isEmpty ? nil : newItemNote
        )

        isSubmittingItem = true

        APIClient.shared.addSharedListItem(item: item) { error in
            DispatchQueue.main.async {
                isSubmittingItem = false
                isAddingItem = false
                newItemName = ""
                newItemNote = ""

                if let error = error {
                    print("❌ Error adding item: \(error.localizedDescription)")
                } else {
                    print("✅ Item added successfully, fetching updated list")

                    APIClient.shared.fetchSharedListItems { items, fetchError in
                        DispatchQueue.main.async {
                            if let fetchError = fetchError {
                                print("❌ Failed to reload shared list: \(fetchError)")
                            } else if let items = items {
                                self.sharedItems = items  // ✅ Update your @State list
                                print("✅ Loaded \(items.count) shared items")
                            }
                        }
                    }
                }
            }
        }
    }



        
}
