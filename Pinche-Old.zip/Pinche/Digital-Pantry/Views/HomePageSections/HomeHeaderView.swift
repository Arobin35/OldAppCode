//
//  HomeHeaderView.swift
//  Digital-Pantry
//
//  Created by Abram Robin  on 2/21/25.
//

import SwiftUI

struct HomeHeaderView: View {
    var user: User // ✅ Passes user to ProfileView

    var body: some View {
        HStack {
            Text("Chef-Pal")
                .font(.system(size: 28, weight: .bold))
                .foregroundColor(.primary)
            Spacer()
            NavigationLink(destination: ProfileView(user: user)) { // ✅ Pass user
                ProfileButton()
            }
        }
        .padding()
        .background(Color(.white))
        .foregroundColor(.white)

        .cornerRadius(15)
        .shadow(radius: 5)
        .padding(.horizontal)
    }
}
