//import SwiftUI
//
//struct ClosestToExpiredView: View {
//    let closestToExpired: [FoodItem]
//
//    var sortedExpiringItems: [FoodItem] {
//        return closestToExpired
//            .sorted { $0.expiration_date < $1.expiration_date } // ✅ Sort by expiration date (earliest first)
//            .prefix(5) // ✅ Take the top 5 closest items
//            .map { $0 } // ✅ Convert back to Array
//    }
//
//    var body: some View {
//        VStack(alignment: .leading, spacing: 10) {
//            Text("Closest to Expired")
//                .font(.headline)
//                .foregroundColor(.green)
//                .padding(.leading)
//
//            ScrollView(.horizontal, showsIndicators: false) {
//                HStack(spacing: 15) {
//                    if sortedExpiringItems.isEmpty {
//                        Text("No expiring items soon.")
//                            .foregroundColor(.gray)
//                            .padding()
//                    } else {
//                        ForEach(sortedExpiringItems, id: \.id) { item in
//                            ExpiringItemView(item: item) // ✅ Display each sorted item
//                        }
//                    }
//                }
//                .padding(.horizontal)
//            }
//        }
//    }
//}
//
//// ✅ ExpiringItemView - Displays Each Expiring Item
//struct ExpiringItemView: View {
//    var item: FoodItem
//
//    var body: some View {
//        VStack(spacing: 5) {
//            Text(item.name)
//                .font(.headline)
//                .foregroundColor(.black)
//                .multilineTextAlignment(.center)
//                .minimumScaleFactor(0.7)
//                .lineLimit(2)
//                .frame(width: 140)
//
//            Text("Expires: \(formatDate(item.expiration_date))") // ✅ Format the date
//                .font(.subheadline)
//                .foregroundColor(.red)
//                .lineLimit(1)
//                .minimumScaleFactor(0.8)
//
//            Image(systemName: "exclamationmark.triangle.fill")
//                .foregroundColor(.orange)
//        }
//        .padding()
//        .frame(width: 200, height: 150)
//        .background(Color(.systemGray6))
//        .cornerRadius(10)
//        .shadow(radius: 2)
//    }
//
//    // ✅ Date Formatter Function
//    func formatDate(_ dateString: String) -> String {
//        let formatter = DateFormatter()
//        formatter.dateFormat = "yyyy-MM-dd" // ✅ Matches API date format
//        if let date = formatter.date(from: dateString) {
//            formatter.dateStyle = .medium
//            return formatter.string(from: date)
//        }
//        return dateString // ✅ Fallback: Display raw string if formatting fails
//    }
//}

import SwiftUI

struct ClosestToExpiredView: View {
    var closestToExpired: [FoodItem]

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Closest to Expired")
                .font(.title2.bold())
                .foregroundColor(.pincheRed)
                .frame(maxWidth: .infinity, alignment: .leading) // ⬅️ Align left
                .padding(.horizontal)

            if closestToExpired.isEmpty {
                Text("No expiring items soon.")
                    .foregroundColor(.gray)
                    .frame(maxWidth: .infinity, alignment: .leading) // ⬅️ Align left
                    .padding(.horizontal)
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 16) {
                        ForEach(closestToExpired) { item in
                            VStack(alignment: .leading, spacing: 8) {
                                Text(item.name.capitalized)
                                    .font(.headline)
                                    .foregroundColor(.pincheText)

                                Text("Expires: \(item.expiration_date)")
                                    .font(.caption)
                                    .foregroundColor(.pincheRed)

                                Spacer()

                                if item.expirationSoon {
                                    Image(systemName: "exclamationmark.triangle.fill")
                                        .foregroundColor(.orange)
                                        .font(.title2)
                                        .frame(maxWidth: .infinity, alignment: .center)
                                }
                            }
                            .padding()
                            .frame(width: 160, height: 120)
                            .background(Color.white)
                            .cornerRadius(12)
                            .shadow(color: .black.opacity(0.05), radius: 3, x: 0, y: 2)
                        }
                    }
                    .padding(.horizontal)
                }
            }
        }
    }
}

extension FoodItem {
    var expirationSoon: Bool {
        guard let date = formattedDate(from: expiration_date) else { return false }
        return Calendar.current.dateComponents([.day], from: Date(), to: date).day ?? 0 <= 3
    }

    private func formattedDate(from string: String) -> Date? {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.date(from: string)
    }
}
