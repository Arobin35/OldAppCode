//import SwiftUI
//
//struct HomeView: View {
//    @Environment(\.presentationMode) var presentationMode // ✅ Allows custom back button
//    @State private var fridgeItems: [FoodItem] = []
//    @State private var pantryItems: [FoodItem] = []
//    @State private var closestToExpired: [FoodItem] = []
//    @State private var savedRecipes: [Recipe] = []
//    @State private var wastedItems: [WastedItemStat] = []
//    private let userID = UserDefaults.standard.string(forKey: "loggedInUserID") ?? ""
//    
//    
//    
//    let savedRecipesKey = "savedRecipes"
//    var user: User // ✅ Passed from SignInView
//    
//    var body: some View {
//        NavigationStack { // ✅ Ensures navigation works correctly
//            VStack(spacing: 40) {
//                Spacer().frame(height: 15) // push everything down a bit
//                ScrollView {
//                    VStack(spacing: 40) {
//                        SavedRecipesView(savedRecipes: $savedRecipes) // ✅ Modularized Saved Recipes
//                        SectionView(title: "Most Wasted Items", color: .blue, items: wastedItems)
//                        ClosestToExpiredView(closestToExpired: closestToExpired) // ✅ Modularized Expired Items
//                    }
//                }
//                
//                BottomNavigationView() // ✅ Modularized Bottom Navigation
//            }
//            .padding(.top, 10)
//            .navigationBarTitle("Chef-Pal Home", displayMode: .inline)
//            .navigationBarBackButtonHidden(true) // ✅ Hides the default back button
//            .navigationBarItems(leading: backButton, trailing: profileButton) // ✅ Adds back & profile buttons
//            .onAppear {
//                loadSavedRecipes()
//                fetchWastedItems()
//                print("🔹 Loaded Recipes in HomeView: \(savedRecipes.count)") // Debugging
//                fetchClosestToExpired()
//                
//            }
//        }
//    }
//    
//    // ✅ Custom Back Button ONLY for HomeView
//    private var backButton: some View {
//        Button(action: {
//            presentationMode.wrappedValue.dismiss() // ✅ Returns to PreviewView
//        }) {
//            HStack {
//                Image(systemName: "chevron.left")
//                Text("Back")
//            }
//        }
//    }
//    
//    // ✅ Profile Button (Restored & Passes User)
//    private var profileButton: some View {
//        NavigationLink(destination: ProfileView(user: user)) {
//            Image(systemName: "person.circle.fill")
//                .resizable()
//                .frame(width: 30, height: 30)
//                .foregroundColor(.blue)
//        }
//    }
//    
//    private func loadSavedRecipes() {
//        guard let userID = UserDefaults.standard.string(forKey: "loggedInUserID") else {
//            print("❌ No user ID found.")
//            return
//        }
//
//        APIClient.shared.fetchUserRecipes(userID: userID) { recipes, error in
//            DispatchQueue.main.async {
//                if let recipes = recipes {
//                    self.savedRecipes = recipes
//                } else {
//                    print("❌ Failed to fetch user recipes: \(error?.localizedDescription ?? "Unknown error")")
//                }
//            }
//        }
//    }
//    
//    private func fetchClosestToExpired() {
//        guard let userID = user.id else {
//            print("❌ User ID missing. Cannot fetch closest to expired items.")
//            return
//        }
//        
//        let dispatchGroup = DispatchGroup()
//        var fridgeItems: [FoodItem] = []
//        var pantryItems: [FoodItem] = []
//        
//        // ✅ Fetch Fridge Items
//        dispatchGroup.enter()
//        APIClient.shared.fetchFridgeItems(userID: String(userID)) { items, error in
//            DispatchQueue.main.async {
//                if let items = items {
//                    fridgeItems = items
//                } else {
//                    print("❌ Error fetching fridge items: \(error?.localizedDescription ?? "Unknown error")")
//                }
//                dispatchGroup.leave()
//            }
//        }
//        
//        // ✅ Fetch Pantry Items
//        dispatchGroup.enter()
//        APIClient.shared.fetchPantryItems(userID: String(userID)) { items, error in
//            DispatchQueue.main.async {
//                if let items = items {
//                    pantryItems = items
//                } else {
//                    print("❌ Error fetching pantry items: \(error?.localizedDescription ?? "Unknown error")")
//                }
//                dispatchGroup.leave()
//            }
//        }
//        
//        // ✅ Ensure both calls finish before updating UI
//        dispatchGroup.notify(queue: .main) {
//            let allItems = (fridgeItems + pantryItems)
//                .sorted { formattedDate(from: $0.expiration_date) < formattedDate(from: $1.expiration_date) }
//            
//            self.closestToExpired = Array(allItems.prefix(5)) // ✅ Take top 5 closest expiring items
//            print("✅ Closest to Expired Items: \(self.closestToExpired)") // Debugging
//        }
//    }
//    
//    
//    private func formattedDate(from dateString: String) -> Date {
//        let formatter = DateFormatter()
//        formatter.dateFormat = "yyyy-MM-dd"
//        
//        if let date = formatter.date(from: dateString) {
//            return date
//        }
//        
//        return Date() // ✅ Default to today instead of distantFuture
//    }
//    
//
//    private func fetchWastedItems() {
//        print("🧪 Fetching wasted items for userID: \(userID)")
//
//        guard let url = URL(string: "http://192.168.1.185:8000/wasted_items/\(userID)") else {
//            print("❌ Invalid URL")
//            return
//        }
//
//        URLSession.shared.dataTask(with: url) { data, _, error in
//            if let error = error {
//                print("❌ Fetch error: \(error.localizedDescription)")
//                return
//            }
//
//            guard let data = data else {
//                print("❌ No data returned")
//                return
//            }
//            
//            if let raw = String(data: data, encoding: .utf8) {
//                   print("📡 Raw wasted response: \(raw)")
//               }
//
//            do {
//                let decoded = try JSONDecoder().decode([WastedItemStat].self, from: data)
//                DispatchQueue.main.async {
//                    self.wastedItems = decoded
//                }
//            } catch {
//                print("❌ Decoding error: \(error)")
//            }
//        }.resume()
//    }
//    
//    // ✅ Modularized Bottom Navigation Bar
//    struct BottomNavigationView: View {
//        var body: some View {
//            HStack {
//                NavButton(destination: ScanView(), icon: "camera.viewfinder", label: "Scan")
//                Spacer()
//                NavButton(destination: FridgeView(), icon: "refrigerator", label: "Fridge")
//                Spacer()
//                NavButton(destination: RecipesView(), icon: "book", label: "Recipes")
//                Spacer()
//                NavButton(destination: PantryView(), icon: "bag", label: "Pantry")
//                Spacer()
//                NavButton(destination: ListView(), icon: "pencil.circle", label: "List")
//            }
//            .padding()
//            .background(Color(.systemGray6))
//            .cornerRadius(15)
//            .shadow(radius: 5)
//            .padding(.horizontal)
//            //.padding(.bottom, 10)
//        }
//    }
//}

import SwiftUI

struct HomeView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var fridgeItems: [FoodItem] = []
    @State private var pantryItems: [FoodItem] = []
    @State private var closestToExpired: [FoodItem] = []
    @State private var savedRecipes: [Recipe] = []
    @State private var wastedItems: [WastedItemStat] = []
    private let userID = UserDefaults.standard.string(forKey: "loggedInUserID") ?? ""

    let savedRecipesKey = "savedRecipes"
    var user: User

    var body: some View {
        NavigationStack {
            VStack(spacing: 40) {
                Divider()
                        .frame(height: 5)
                        .background(.white)
                        .ignoresSafeArea(edges: .top)

                ScrollView {
                    VStack(spacing: 40) {
                        SavedRecipesView(savedRecipes: $savedRecipes)
                        WastedHomeView(title: "Most Wasted Items", color: .pincheRed, items: wastedItems)
                        ClosestToExpiredView(closestToExpired: closestToExpired)
                    }
                }
                BottomNavigationView()
            }
            .padding(.top, 10)
            .background(Color.pincheCream)
            .navigationBarTitle("Pinché Home", displayMode: .inline)
            .navigationBarBackButtonHidden(true)
            .navigationBarItems(leading: backButton, trailing: profileButton)
            .onAppear {
                loadSavedRecipes()
                fetchWastedItems()
                fetchClosestToExpired()
            }
        }
    }

    private var backButton: some View {
        Button(action: {
            presentationMode.wrappedValue.dismiss()
        }) {
            HStack {
                Image(systemName: "chevron.left")
                Text("Back")
            }
            .foregroundColor(.blue)
        }
    }

    private var profileButton: some View {
        NavigationLink(destination: ProfileView(user: user)) {
            Image(systemName: "person.circle.fill")
                .resizable()
                .frame(width: 30, height: 30)
                .foregroundColor(.pincheRed)
        }
    }

    private func loadSavedRecipes() {
        guard let userID = UserDefaults.standard.string(forKey: "loggedInUserID") else { return }
        APIClient.shared.fetchUserRecipes(userID: userID) { recipes, error in
            DispatchQueue.main.async {
                self.savedRecipes = recipes ?? []
            }
        }
    }

    private func fetchClosestToExpired() {
        guard let userID = user.id else { return }
        let dispatchGroup = DispatchGroup()
        var fridgeItems: [FoodItem] = []
        var pantryItems: [FoodItem] = []

        dispatchGroup.enter()
        APIClient.shared.fetchFridgeItems(userID: String(userID)) { items, _ in
            fridgeItems = items ?? []
            dispatchGroup.leave()
        }

        dispatchGroup.enter()
        APIClient.shared.fetchPantryItems(userID: String(userID)) { items, _ in
            pantryItems = items ?? []
            dispatchGroup.leave()
        }

        dispatchGroup.notify(queue: .main) {
            let allItems = (fridgeItems + pantryItems)
                .sorted { formattedDate(from: $0.expiration_date) < formattedDate(from: $1.expiration_date) }
            self.closestToExpired = Array(allItems.prefix(5))
        }
    }

    private func formattedDate(from dateString: String) -> Date {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.date(from: dateString) ?? Date()
    }

    private func fetchWastedItems() {
        guard let url = URL(string: "http://192.168.1.185:8000/wasted_items/\(userID)") else { return }
        URLSession.shared.dataTask(with: url) { data, _, error in
            guard let data = data, error == nil else { return }
            if let decoded = try? JSONDecoder().decode([WastedItemStat].self, from: data) {
                DispatchQueue.main.async {
                    self.wastedItems = decoded
                }
            }
        }.resume()
    }

    struct BottomNavigationView: View {
        var body: some View {
            HStack {
                NavButton(destination: ScanView(), icon: "camera.viewfinder", label: "Scan")
                Spacer()
                NavButton(destination: FridgeView(), icon: "refrigerator", label: "Fridge")
                Spacer()
                NavButton(destination: RecipesView(), icon: "book", label: "Recipes")
                Spacer()
                NavButton(destination: PantryView(), icon: "bag", label: "Pantry")
                Spacer()
                NavButton(destination: ListView(), icon: "pencil.circle", label: "List")
            }
            .padding()
            .background(Color.pincheField)
            .cornerRadius(15)
            .shadow(color: .black.opacity(0.1), radius: 5)
            .padding(.horizontal)
        }
    }
}


