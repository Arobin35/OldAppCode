//import SwiftUI
//
//struct SavedRecipesView: View {
//    @Binding var savedRecipes: [Recipe] // ✅ Ensure Binding for updates
//
//    var body: some View {
//        VStack(alignment: .leading, spacing: 10) {
//            Text("Saved Recipes")
//                .font(.headline)
//                .foregroundColor(.pink)
//                .padding(.leading)
//
//            ScrollView(.horizontal, showsIndicators: false) {
//                HStack(spacing: 15) {
//                    if savedRecipes.isEmpty {
//                        Text("No saved recipes yet.")
//                            .foregroundColor(.gray)
//                            .padding()
//                    } else {
//                        ForEach(savedRecipes) { recipe in
//                            NavigationLink(destination: RecipeDetailView(recipe: recipe)) {
//                                RecipeButton(recipe: recipe) // ✅ Uses updated button
//                            }
//                        }
//                    }
//                }
//                .padding(.horizontal)
//            }
//        }
//    }
//}
//
//// ✅ Updated `RecipeButton` - Bigger and Fully Visible
//
//struct RecipeButton: View {
//    var recipe: Recipe
//
//    var body: some View {
//        VStack {
//            Text(recipe.title)
//                .font(.headline)
//                .foregroundColor(.white)
//                .padding()
//                .frame(maxWidth: 300) // ✅ Expands width up to 250 but no more
//                .multilineTextAlignment(.center) // ✅ Ensures text is centered
//                .minimumScaleFactor(0.5) // ✅ Shrinks text (down to 50%) if needed
//                .lineLimit(nil) // ✅ Allows full text visibility (unlimited lines)
//                .fixedSize(horizontal: false, vertical: true) // ✅ Prevents truncation & allows wrapping
//        }
//        .padding()
//        .frame(minWidth: 150, maxWidth: 300, minHeight: 80, maxHeight: 120) // ✅ Controlled box size
//        .background(Color.red)
//        .cornerRadius(10)
//        .shadow(radius: 2)
//    }
//}
import SwiftUI

struct SavedRecipesView: View {
    @Binding var savedRecipes: [Recipe] // ✅ Ensure Binding for updates

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Saved Recipes")
                .font(.title2.bold())
                .foregroundColor(.pincheRed)
                .padding(.leading)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 15) {
                    if savedRecipes.isEmpty {
                        Text("No saved recipes yet.")
                            .foregroundColor(.gray)
                            //.padding(.horizontal)
                    } else {
                        ForEach(savedRecipes) { recipe in
                            NavigationLink(destination: RecipeDetailView(recipe: recipe)) {
                                RecipeButton(recipe: recipe) // ✅ Uses updated button
                            }
                        }
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

// ✅ Updated `RecipeButton` - Bigger and Fully Visible

struct RecipeButton: View {
    var recipe: Recipe

    var body: some View {
        VStack {
            Text(recipe.title)
                .font(.headline)
                .foregroundColor(.pincheText)
                .padding()
                .frame(maxWidth: 300)
                .multilineTextAlignment(.center)
                .minimumScaleFactor(0.5)
                .lineLimit(nil)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding()
        .frame(minWidth: 150, maxWidth: 300, minHeight: 80, maxHeight: 120)
        .background(Color.white)
        .cornerRadius(10)
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
}
