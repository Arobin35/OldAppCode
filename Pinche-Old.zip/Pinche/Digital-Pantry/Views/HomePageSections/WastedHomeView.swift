//import SwiftUI
//
//struct SectionView: View {
//    var title: String
//    var color: Color
//    var items: [WastedItemStat]
//
//    var body: some View {
//        VStack(alignment: .leading, spacing: 10) {
//            HStack {
//                Text(title)
//                    .font(.headline)
//                    .bold()
//                    .foregroundColor(color)
//                Spacer()
//            }
//            .padding(.horizontal)
//
//            if items.isEmpty {
//                HStack {
//                    Text("No items to display.")
//                        .foregroundColor(.gray)
//                    Spacer()
//                }
//                .padding(.horizontal)
//            } else {
//                ScrollView(.horizontal, showsIndicators: false) {
//                    HStack(spacing: 16) {
//                        ForEach(items.sorted(by: { $0.count > $1.count })) { item in
//                            RoundedRectangle(cornerRadius: 15)
//                                .fill(color.opacity(0.15))
//                                .frame(width: 120, height: 120)
//                                .overlay(
//                                    VStack(spacing: 8) {
//                                        Text(item.name)
//                                            .font(.subheadline)
//                                            .multilineTextAlignment(.center)
//                                            .foregroundColor(color)
//                                            .lineLimit(2)
//                                            .minimumScaleFactor(0.7)
//
//                                        Text("\(item.count) wasted")
//                                            .font(.caption)
//                                            .foregroundColor(.secondary)
//                                    }
//                                    .padding()
//                                )
//                                .shadow(radius: 4)
//                        }
//                    }
//                    .padding(.horizontal)
//                }
//            }
//        }
//    }
//}

import SwiftUI

struct WastedHomeView: View {
    var title: String
    var color: Color
    var items: [WastedItemStat]

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(title)
                    .font(.title2.bold())
                    .foregroundColor(.pincheRed)
                Spacer()
            }
            .padding(.horizontal)

            if items.isEmpty {
                HStack {
                    Text("No items to display.")
                        .foregroundColor(.gray)
                    Spacer()
                }
                .padding(.horizontal)
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 16) {
                        ForEach(items.sorted(by: { $0.count > $1.count })) { item in
                            RoundedRectangle(cornerRadius: 15)
                                .fill(Color.white)
                                .frame(width: 140, height: 120)
                                .overlay(
                                    VStack(spacing: 8) {
                                        Text(item.name)
                                            .font(.subheadline.bold())
                                            .font(.system(size:20))
                                            .multilineTextAlignment(.center)
                                            .foregroundColor(.black)
                                            .lineLimit(2)
                                            .minimumScaleFactor(0.7)

                                        Text("\(item.count) wasted")
                                            .font(.caption)
                                            .foregroundColor(.pincheRed)
                                    }
                                    .padding()
                                )
                                .shadow(color: .black.opacity(0.05), radius: 3, x: 0, y: 2)
                        }
                    }
                    .padding(.horizontal)
                }
            }
        }
    }
}



