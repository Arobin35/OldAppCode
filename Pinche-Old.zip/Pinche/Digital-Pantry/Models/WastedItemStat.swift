//
//  WastedItemStat.swift
//  Digital-Pantry
//
//  Created by Abram Robin  on 5/21/25.
//
import SwiftUI
struct WastedItemStat: Identifiable, Codable {
    //var id: UUID { UUID() }  // dynamically generated
    var id: String { name }
    var name: String
    var count: Int           // ✅ changed from `let` to `var`
}
