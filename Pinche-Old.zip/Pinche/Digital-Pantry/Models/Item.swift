//
//  Item.swift
//  Digital-Pantry
//
//  Created by Abram Robin  on 2/14/25.
//
import SwiftData
import Foundation

@Model
class Item {
    var id: UUID
    var name: String
    var quantity: Int
    var expirationDate: Date

    init(id: UUID = UUID(), name: String, quantity: Int, expirationDate: Date) {
        self.id = id
        self.name = name
        self.quantity = quantity
        self.expirationDate = expirationDate
    }
}

