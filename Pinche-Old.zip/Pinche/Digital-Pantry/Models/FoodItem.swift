//
//  FoodItem.swift
//  Digital-Pantry
//
//  Created by Abram Robin on 2/28/25.
//

import Foundation

struct FoodItem: Identifiable, Codable {
    var id: Int?
    var name: String
    var quantity: Int
    var expiration_date: String
    var user_id: Int

    enum CodingKeys: String, CodingKey {
        case id
        case name
        case quantity
        case expiration_date
        case user_id
    }

    init(id: Int? = nil, name: String, quantity: Int, expiration_date: String, userID: Int) {
        self.id = id
        self.name = name
        self.quantity = quantity
        self.expiration_date = expiration_date
        self.user_id = userID
    }
}


struct FoodItemsResponse: Codable {
    let food_items: [FoodItem]
}
