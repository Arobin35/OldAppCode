//
//  User.swift
//  Digital-Pantry
//
//  Created by Abram Robin  on 6/8/25.
//
import Foundation

struct User: Codable {
    var id: Int? // ✅ This is the userID from the database
    var username: String
    var email: String?
    var phone: String?
    var passwordHash: String
    var profilePicture: String?
    var familyID: String?
    var createdAt: String // ✅ Matches "created_at" from API

    // ✅ Fix coding keys to match API JSON fields
    enum CodingKeys: String, CodingKey {
        case id // ✅ Ensure this is included
        case username
        case email
        case phone
        case passwordHash = "password_hash" // ✅ Matches API response field name
        case profilePicture = "profile_picture" // ✅ Matches API response field name
        case familyID = "family_id" // ✅ Matches API response field name
        case createdAt = "created_at" // ✅ Matches API response field name
    }
}


