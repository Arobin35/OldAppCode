//
//  RecipeSummary.swift
//  Digital-Pantry
//
//  Created by Abram Robin  on 6/7/25.
//
import SwiftUI
struct RecipeSummary: Codable, Identifiable {
    let id: Int                  // ✅ From backend
    let title: String
    let ingredients: String
    let instructions: String
    let created_at: String
}
