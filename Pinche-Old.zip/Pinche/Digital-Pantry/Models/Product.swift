//
//  Product.swift
//  Digital-Pantry
//
//  Created by Abram Robin  on 1/26/25.
//
import Foundation

struct BarcodeLookupResponse: Codable {
    let products: [Product]
}

struct Product: Codable {
    let title: String
    let image: String
}

