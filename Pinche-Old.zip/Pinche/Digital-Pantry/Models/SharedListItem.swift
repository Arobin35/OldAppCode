//
//  SharedListItem.swift
//  Digital-Pantry
//
//  Created by Abram Robin  on 3/27/25.
//
struct SharedListItem: Codable, Identifiable {
    var id: Int?
    var name: String
    var family_id: String?
    var added_by_user_id: Int?
    var timestamp: String
    var notes: String?
}
