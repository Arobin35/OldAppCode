//
//  RecipeStat.swift
//  Digital-Pantry
//
//  Created by Abram Robin  on 5/28/25.
//

import Foundation

struct RecipeStat: Codable, Identifiable {
    var id: Int?               // Nullable if not yet saved
    let title: String
    let ingredients: String
    let instructions: String
    let created_at: String?    // Optional if saving later
    let rating: Int?           // Optional for now
    let nutritionInfo: String? // Optional for now

    var displayDate: String {
        created_at ?? "N/A"
    }
}
