import Foundation

class APIClient {
    static let shared = APIClient()
    // ------------------ FRIDGE MANAGMENT ------------------ //

    // ------------------ FETCH FRIDGE ITEMS (With userID) ------------------ //
    func fetchFridgeItems(userID: String, completion: @escaping ([FoodItem]?, Error?) -> Void) {
        let encodedUserID = userID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? ""
        let urlString = "http://192.168.1.36:8000/food_items/\(encodedUserID)"

        guard let url = URL(string: urlString) else {
            print("❌ Invalid URL: \(urlString)")
            completion(nil, NSError(domain: "Invalid URL", code: 400, userInfo: nil))
            return
        }

        print("📡 Sending GET request to: \(urlString)")

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("❌ Network error: \(error.localizedDescription)")
                completion(nil, error)
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                print("📡 Response Status Code: \(httpResponse.statusCode)")
            }

            guard let data = data else {
                print("❌ No data received from backend")
                completion(nil, NSError(domain: "No Data", code: 500, userInfo: nil))
                return
            }

            if let jsonString = String(data: data, encoding: .utf8) {
                print("📡 API Response: \(jsonString)")  // ✅ Debugging log
            }

            do {
                let response = try JSONDecoder().decode(FoodItemsResponse.self, from: data)
                print("✅ Successfully fetched \(response.food_items.count) food items")
                completion(response.food_items, nil)
            } catch {
                print("❌ JSON Decoding error: \(error.localizedDescription)")
                completion(nil, error)
            }
        }.resume()
    }
    
    
    
    
    func addFridgeItem(_ item: FoodItem, completion: @escaping (Error?) -> Void) {
        let urlString = "http://192.168.1.185:8000/food_items"

        guard let url = URL(string: urlString) else {
            completion(NSError(domain: "", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid URL"]))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        // ❗️Drop `id` before encoding
        struct FoodItemPayload: Codable {
            var name: String
            var quantity: Int
            var expiration_date: String
            var user_id: String  // ✅ must be String
        }

        let payload = FoodItemPayload(
            name: item.name,
            quantity: item.quantity,
            expiration_date: item.expiration_date,
            user_id: String(item.user_id) // ✅ ensure it's String
        )

        do {
            let jsonData = try JSONEncoder().encode(payload)
            request.httpBody = jsonData

            if let jsonString = String(data: jsonData, encoding: .utf8) {
                print("📡 Sending POST request to \(urlString) with JSON payload:\n\(jsonString)")
            }
        } catch {
            completion(error)
            return
        }

        URLSession.shared.dataTask(with: request) { _, response, error in
            if let error = error {
                completion(error)
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                print("📡 Server response status: \(httpResponse.statusCode)")
                if httpResponse.statusCode != 201 {
                    completion(NSError(domain: "Server Error", code: httpResponse.statusCode, userInfo: nil))
                } else {
                    print("✅ Successfully added item!")
                    completion(nil)
                }
            }
        }.resume()
    }
    
    
    
    
    
    // ✅ Update an existing Food Item
func updateFridgeItem(_ item: FoodItem, userID: String, completion: @escaping (Error?) -> Void) {
    guard let itemID = item.id else {
        completion(NSError(domain: "", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid Item ID"]))
        return
    }

    let urlString = "http://192.168.1.185:8000/food_items/\(itemID)/\(userID)"
    guard let url = URL(string: urlString) else {
        completion(NSError(domain: "", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid URL"]))
        return
    }

    var request = URLRequest(url: url)
    request.httpMethod = "PATCH"
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")

    // ✅ Now sending BOTH `quantity` and `expiration_date`
    let body: [String: Any] = [
        "quantity": item.quantity,
        "expiration_date": item.expiration_date // ✅ Now included
    ]
    
    request.httpBody = try? JSONSerialization.data(withJSONObject: body)

    print("📡 Sending PATCH request to \(urlString) with payload: \(body)")

    URLSession.shared.dataTask(with: request) { _, response, error in
        if let error = error {
            completion(error)
            return
        }

        if let httpResponse = response as? HTTPURLResponse {
            print("📡 Server response status: \(httpResponse.statusCode)")
            if httpResponse.statusCode != 200 {
                completion(NSError(domain: "", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: "Server error"]))
            } else {
                completion(nil) // ✅ Success
            }
        }
    }.resume()
}
    
    // ✅ Delete a Food Item by name (for the logged-in user)
func deleteFridgeItem(name: String, userID: String, completion: @escaping (Error?) -> Void) {
    let encodedName = name.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? name
    let urlString = "http://192.168.1.185:8000/food_items/\(encodedName)?user_id=\(userID)"
    
    guard let url = URL(string: urlString) else {
        completion(NSError(domain: "", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid URL"]))
        return
    }

    var request = URLRequest(url: url)
    request.httpMethod = "DELETE"

    print("🗑️ Sending DELETE request to \(urlString)") // Debugging

    URLSession.shared.dataTask(with: request) { _, response, error in
        if let error = error {
            print("❌ Delete request failed: \(error.localizedDescription)")
            completion(error)
            return
        }

        if let httpResponse = response as? HTTPURLResponse {
            print("📡 Server response status: \(httpResponse.statusCode)") // Debugging
            if httpResponse.statusCode != 200 {
                completion(NSError(domain: "", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: "Server error"]))
            } else {
                print("✅ Item '\(name)' deleted successfully!") // Debugging
                completion(nil) // ✅ Success
            }
        }
    }.resume()
}

    
    
    // ------------------ PANTRY MANAGMENT ------------------ //

    // ------------------ FETCH PANTRY ITEMS (With userID) ------------------ //
    func fetchPantryItems(userID: String, completion: @escaping ([FoodItem]?, Error?) -> Void) {
        guard let url = URL(string: "http://192.168.1.185:8000/pantry_items/\(userID)") else {
            print("❌ Invalid URL for fetching pantry items")
            completion(nil, NSError(domain: "Invalid URL", code: 400, userInfo: nil))
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("❌ Network error: \(error.localizedDescription)")
                completion(nil, error)
                return
            }

            guard let data = data else {
                print("❌ No data received from backend")
                completion(nil, NSError(domain: "No Data", code: 500, userInfo: nil))
                return
            }

            // ✅ Debugging: Print Raw JSON Response
            if let jsonString = String(data: data, encoding: .utf8) {
                print("📡 Raw API Response: \(jsonString)")
            }

            do {
                let response = try JSONDecoder().decode(FoodItemsResponse.self, from: data)
                print("✅ Successfully fetched \(response.food_items.count) pantry items")
                completion(response.food_items, nil)
            } catch {
                print("❌ JSON Decoding error: \(error.localizedDescription)")
                completion(nil, error)
            }
        }.resume()
    }
    
    // ------------------ UPDATE PANTRY ITEM (With userID) ------------------ //
    func updatePantryItem(_ item: FoodItem, userID: String, completion: @escaping (Error?) -> Void) {
        guard let itemID = item.id else {
            completion(NSError(domain: "", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid Item ID"]))
            return
        }

        let urlString = "http://192.168.1.185:8000/pantry_items/\(itemID)/\(userID)"
        guard let url = URL(string: urlString) else {
            completion(NSError(domain: "", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid URL"]))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "PATCH"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        // ✅ Send only required fields for pantry update
        let body: [String: Any] = [
            "quantity": item.quantity,
            "expiration_date": item.expiration_date
        ]
        
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        print("📡 Sending PATCH request to \(urlString) with payload: \(body)")

        URLSession.shared.dataTask(with: request) { _, response, error in
            if let error = error {
                completion(error)
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                print("📡 Server response status: \(httpResponse.statusCode)")
                if httpResponse.statusCode != 200 {
                    completion(NSError(domain: "", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: "Server error"]))
                } else {
                    completion(nil) // ✅ Success
                }
            }
        }.resume()
    }



    // ------------------ ADD PANTRY ITEM  ------------------ //
//

    func addPantryItem(_ item: FoodItem, completion: @escaping (Error?) -> Void) {
        let urlString = "http://192.168.1.185:8000/pantry_items"

        guard let url = URL(string: urlString) else {
            completion(NSError(domain: "", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid URL"]))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        guard let userIDInt = Int(UserDefaults.standard.string(forKey: "loggedInUserID") ?? "0") else {
            print("❌ Error: User ID is not valid")
            completion(NSError(domain: "", code: 400, userInfo: [NSLocalizedDescriptionKey: "User ID invalid"]))
            return
        }

        var newItem = item
        newItem.user_id = userIDInt // ✅ Ensure user_id is correctly set

        // ✅ Remove `id` field to avoid FastAPI rejecting it
        let body: [String: Any] = [
            "name": newItem.name,
            "quantity": newItem.quantity,
            "expiration_date": newItem.expiration_date,
            "user_id": String(userIDInt) // ✅ Convert to String if FastAPI expects TEXT
        ]

        do {
            let jsonData = try JSONSerialization.data(withJSONObject: body)

            if let jsonString = String(data: jsonData, encoding: .utf8) {
                print("📡 Sending POST request to \(urlString) with JSON payload: \(jsonString)")
            }

            request.httpBody = jsonData
        } catch {
            completion(error)
            return
        }

        URLSession.shared.dataTask(with: request) { _, response, error in
            if let error = error {
                print("❌ Failed to add item: \(error.localizedDescription)")
                completion(error)
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                print("📡 Server response status: \(httpResponse.statusCode)")
                if httpResponse.statusCode != 201 {
                    completion(NSError(domain: "Server Error", code: httpResponse.statusCode, userInfo: nil))
                } else {
                    print("✅ Successfully added item!")
                    completion(nil) // ✅ Success
                }
            }
        }.resume()
    }
    
    // ------------------ DELETE PANTRY ITEM (With userID) ------------------ //
    func deletePantryItem(name: String, userID: String, completion: @escaping (Error?) -> Void) {
        guard let encodedName = name.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) else {
            completion(NSError(domain: "Encoding Error", code: 400, userInfo: nil))
            return
        }

        guard let url = URL(string: "http://192.168.1.185:8000/pantry_items/\(encodedName)?user_id=\(userID)") else {
            completion(NSError(domain: "Invalid URL", code: 400, userInfo: nil))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"

        URLSession.shared.dataTask(with: request) { _, response, error in
            if let error = error {
                completion(error)
                return
            }

            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
                completion(nil)
            } else {
                completion(NSError(domain: "Server Error", code: 500, userInfo: nil))
            }
        }.resume()
    }
    
    
    
    
    
    
    // ------------------ USER MANAGMENT ------------------ //
    
    
    

    // ------------------ VERIFY USER EXISTENCE ------------------ //
    func verifyUserExists(identifier: String, completion: @escaping (Bool, String?) -> Void) {
        guard let url = URL(string: "http://192.168.1.185:8000/verify_user_exists") else {
            completion(false, "❌ Invalid URL")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        let requestBody: [String: String] = ["identifier": identifier]

        do {
            let jsonData = try JSONSerialization.data(withJSONObject: requestBody)
            request.httpBody = jsonData

            print("📡 Sending Sign-In Request: \(String(data: jsonData, encoding: .utf8) ?? "Invalid JSON")")  // ✅ Debugging print
        } catch {
            completion(false, "❌ Error encoding request.")
            return
        }

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(false, "❌ Network error: \(error.localizedDescription)")
                return
            }

            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200,
               let data = data {
                do {
                    let result = try JSONSerialization.jsonObject(with: data) as? [String: Any]
                    let exists = result?["exists"] as? Bool ?? false
                    completion(exists, nil)
                } catch {
                    completion(false, "❌ JSON parsing error.")
                }
            } else {
                completion(false, "❌ Server error.")
            }
        }.resume()
    }

    // ------------------ FETCH USER PROFILE ------------------ //
    func fetchUserProfile(userID: String, completion: @escaping (User?, Error?) -> Void) {
        let encodedUserID = userID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? ""
        guard let url = URL(string: "http://192.168.1.185:8000/users/\(encodedUserID)") else {
            completion(nil, NSError(domain: "Invalid URL", code: 400, userInfo: nil))
            return
        }

        URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error {
                completion(nil, error)
                return
            }

            guard let data = data else {
                completion(nil, NSError(domain: "No Data", code: 500, userInfo: nil))
                return
            }

            if let jsonString = String(data: data, encoding: .utf8) {
                print("📡 Raw API Response: \(jsonString)")  // ✅ Debugging log
            }

            do {
                let user = try JSONDecoder().decode(User.self, from: data)
                completion(user, nil)
            } catch {
                print("❌ JSON Decoding error: \(error.localizedDescription)")
                completion(nil, error)
            }
        }.resume()
    }

    // ✅ Adds a user

    func addUser(_ user: User, completion: @escaping (Int?, String?) -> Void) {
        guard let url = URL(string: "http://192.168.1.185:8000/users") else {
            completion(nil, "❌ Invalid URL")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            let encoder = JSONEncoder()
            encoder.keyEncodingStrategy = .convertToSnakeCase
            let jsonData = try encoder.encode(user)
            request.httpBody = jsonData

            print("📡 Sending Request to API: \(String(data: jsonData, encoding: .utf8) ?? "Invalid JSON")")
        } catch {
            completion(nil, "❌ Error encoding user data.")
            return
        }

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("❌ Network error: \(error.localizedDescription)")
                completion(nil, error.localizedDescription)
                return
            }

            guard let data = data else {
                completion(nil, "❌ No data received from server")
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                print("📡 Response Status Code: \(httpResponse.statusCode)")
            }

            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let userID = json["user_id"] as? Int {
                    completion(userID, nil)
                } else {
                    completion(nil, "❌ Failed to parse user ID from response")
                }
            } catch {
                completion(nil, "❌ JSON parsing error: \(error.localizedDescription)")
            }
        }.resume()
    }
    
    
    func fetchUserID(identifier: String, completion: @escaping (Int?, String?) -> Void) {
        guard let encodedIdentifier = identifier.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else {
            completion(nil, "❌ Encoding Error")
            return
        }

        let urlString = "http://192.168.1.185:8000/get_user_id?identifier=\(encodedIdentifier)"
        guard let url = URL(string: urlString) else {
            completion(nil, "❌ Invalid URL")
            return
        }

        print("📡 Fetching User ID for: \(identifier) (Encoded: \(encodedIdentifier))")

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(nil, "❌ Network error: \(error.localizedDescription)")
                return
            }

            guard let data = data else {
                completion(nil, "❌ No data received from backend")
                return
            }

            do {
                let result = try JSONDecoder().decode([String: Int].self, from: data)
                if let userID = result["user_id"] {
                    completion(userID, nil)
                } else {
                    completion(nil, "❌ User ID not found in response")
                }
            } catch {
                completion(nil, "❌ JSON parsing error")
            }
        }.resume()
    }

    func updateUserProfile(_ user: User, completion: @escaping (Error?) -> Void) {
        guard let userID = user.id,
              let url = URL(string: "http://192.168.1.185:8000/users/\(userID)") else {
            completion(NSError(domain: "Invalid URL or missing user ID", code: 400))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            let encoder = JSONEncoder()
            encoder.keyEncodingStrategy = .convertToSnakeCase
            let jsonData = try encoder.encode(user)
            request.httpBody = jsonData
        } catch {
            completion(error)
            return
        }

        URLSession.shared.dataTask(with: request) { _, response, error in
            if let error = error {
                completion(error)
                return
            }

            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
                completion(nil)
            } else {
                completion(NSError(domain: "Server Error", code: 500))
            }
        }.resume()
    }
    
    
    // ------------------ LIST ENDPOINTS ------------------ //
    func fetchSharedListItems(completion: @escaping ([SharedListItem]?, Error?) -> Void) {
        guard let userIDString = UserDefaults.standard.string(forKey: "loggedInUserID"),
              let userID = Int(userIDString) else {
            completion(nil, NSError(domain: "User ID missing", code: 400))
            return
        }

        let familyID = UserDefaults.standard.string(forKey: "loggedInFamilyID")
        print("👨‍👩‍👧‍👦 Family ID from defaults: \(familyID ?? "nil")")

        var urlString: String

        if let familyID = familyID,
           !familyID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
           let encodedFamilyID = familyID.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
            urlString = "http://192.168.1.185:8000/shared_list_items?family_id=\(encodedFamilyID)"
        } else {
            urlString = "http://192.168.1.185:8000/shared_list_items?user_id=\(userID)"
            print("⚠️ No valid family ID found, falling back to user-only list")
        }

        print("🌐 Final fetch URL: \(urlString)")

        guard let url = URL(string: urlString) else {
            completion(nil, NSError(domain: "Invalid URL", code: 400))
            return
        }

        URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error {
                completion(nil, error)
                return
            }

            guard let data = data else {
                completion(nil, NSError(domain: "No data", code: 500))
                return
            }

            do {
                let decoder = JSONDecoder()
                decoder.keyDecodingStrategy = .convertFromSnakeCase
                let items = try decoder.decode([SharedListItem].self, from: data)
                print("✅ Decoded shared items count: \(items.count)")
                completion(items, nil)
            } catch {
                print("❌ Decoding error: \(error)")
                completion(nil, error)
            }
        }.resume()
    }


    // ------------------ DELETE SHARED LIST ITEM ------------------ //
    func deleteSharedListItem(id: Int, completion: @escaping (Error?) -> Void) {
        guard let url = URL(string: "http://192.168.1.185:8000/shared_list_items/\(id)") else {
            completion(NSError(domain: "Invalid URL", code: 400))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"

        URLSession.shared.dataTask(with: request) { _, response, error in
            completion(error)
        }.resume()
    }

    
    // ------------------ ADD SHARED LIST ITEM ------------------ //

    func addSharedListItem(item: SharedListItem, completion: @escaping (Error?) -> Void) {
        guard let url = URL(string: "http://192.168.1.185:8000/shared_list_items") else {
            completion(NSError(domain: "Invalid URL", code: 400))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            let encoder = JSONEncoder()
            request.httpBody = try encoder.encode(item)
        } catch {
            completion(error)
            return
        }

        URLSession.shared.dataTask(with: request) { _, response, error in
            completion(error)
        }.resume()
    }
    
    
    // ------------------ RECIPE ENDPOINTS ------------------ //
    //Makes the Recipe
    func makeRecipe(userID: String, notes: String = "", completion: @escaping (String?, Error?) -> Void) {
        let urlString = "http://192.168.1.185:8000/generate_recipe?user_id=\(userID)&notes=\(notes.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")"

        guard let url = URL(string: urlString) else {
            completion(nil, NSError(domain: "Invalid URL", code: 400, userInfo: nil))
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(nil, error)
                return
            }

            guard let data = data else {
                completion(nil, NSError(domain: "No Data", code: 500, userInfo: nil))
                return
            }

            do {
                let result = try JSONDecoder().decode([String: String].self, from: data)
                completion(result["recipe"], nil)
            } catch {
                completion(nil, error)
            }
        }.resume()
    }
    
    
    func saveRecipe(_ recipe: RecipeStat, userID: String, completion: @escaping (Result<Void, Error>) -> Void) {
        guard let url = URL(string: "http://192.168.1.185:8000/save_recipe") else {
            completion(.failure(NSError(domain: "Invalid URL", code: 400)))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload: [String: Any] = [
            "user_id": userID,
            "title": recipe.title,
            "ingredients": recipe.ingredients,
            "instructions": recipe.instructions,
            "rating": recipe.rating ?? 0,
            "nutrition_info": recipe.nutritionInfo ?? ""
        ]

        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: payload)
        } catch {
            completion(.failure(error))
            return
        }

        URLSession.shared.dataTask(with: request) { _, _, error in
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.success(()))
            }
        }.resume()
    }
    
    func deleteRecipe(id: Int, completion: @escaping (Result<Void, Error>) -> Void) {
        guard let url = URL(string: "http://192.168.1.185:8000/recipes/\(id)") else {
            completion(.failure(NSError(domain: "Invalid URL", code: 400)))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"

        URLSession.shared.dataTask(with: request) { _, response, error in
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.success(()))
            }
        }.resume()
    }
    
    func fetchUserRecipes(userID: String, completion: @escaping ([Recipe]?, Error?) -> Void) {
        let urlString = "http://192.168.1.185:8000/user_recipes/\(userID)"
        guard let url = URL(string: urlString) else {
            completion(nil, NSError(domain: "Invalid URL", code: 400))
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(nil, error)
                return
            }

            guard let data = data else {
                completion(nil, NSError(domain: "No data", code: 500))
                return
            }

            do {
                let rawRecipes = try JSONSerialization.jsonObject(with: data) as? [[String: Any]]
                let decoded = rawRecipes?.compactMap { dict -> Recipe? in
                    guard
                        let title = dict["title"] as? String,
                        let ingredientsText = dict["ingredients"] as? String,
                        let instructions = dict["instructions"] as? String,
                        let idString = dict["id"] as? Int
                    else { return nil }

                    let ingredients = ingredientsText.components(separatedBy: "\n")
                    return Recipe(id: UUID(uuidString: "\(idString)") ?? UUID(), title: title, ingredients: ingredients, instructions: instructions)
                }
                completion(decoded, nil)
            } catch {
                completion(nil, error)
            }
        }.resume()
    }
    
    // ------------------ WWASTED ITEM ENDPOINTS ------------------ //

    func markPantryItemAsWasted(item: FoodItem, userID: String, completion: @escaping (Error?) -> Void) {
        guard let encodedName = item.name.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
              let url = URL(string: "http://192.168.1.185:8000/wasted_items/\(encodedName)?user_id=\(userID)") else {
            completion(NSError(domain: "Invalid URL", code: 400, userInfo: nil))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        URLSession.shared.dataTask(with: request) { _, response, error in
            if let error = error {
                completion(error)
            } else {
                completion(nil)
            }
        }.resume()
    }
    
    
    func markFridgeItemAsWasted(item: FoodItem, userID: String, completion: @escaping (Error?) -> Void) {
        guard let encodedName = item.name.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
              let url = URL(string: "http://192.168.1.185:8000/wasted_items/\(encodedName)?user_id=\(userID)") else {
            completion(NSError(domain: "Invalid URL", code: 400, userInfo: nil))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        URLSession.shared.dataTask(with: request) { _, response, error in
            if let error = error {
                completion(error)
            } else {
                completion(nil)
            }
        }.resume()
    }
    
    func updateWastedItem(itemName: String, userID: String, quantity: Int, completion: @escaping (Error?) -> Void) {
        guard let encodedName = itemName.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
              let url = URL(string: "http://192.168.1.185:8000/wasted_items/\(encodedName)/\(userID)") else {
            completion(NSError(domain: "Invalid URL", code: 400))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload: [String: Int] = ["quantity": quantity]

        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: payload)
            print("📡 PUT Payload: \(String(data: request.httpBody!, encoding: .utf8)!)")
        } catch {
            completion(error)
            return
        }

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let httpResponse = response as? HTTPURLResponse {
                print("📡 Server response status: \(httpResponse.statusCode)")
            }

            if let data = data, let responseText = String(data: data, encoding: .utf8) {
                print("📡 Response Body: \(responseText)")
            }

            if let error = error {
                print("❌ Network error: \(error.localizedDescription)")
                completion(error)
            } else {
                completion(nil)
            }
        }.resume()
    }
    
    
    func deleteWastedItem(itemName: String, userID: String, completion: @escaping (Error?) -> Void) {
        guard let encodedName = itemName.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
              let url = URL(string: "http://192.168.1.185:8000/wasted_items/\(encodedName)/\(userID)") else {
            completion(NSError(domain: "Invalid URL", code: 400))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"

        URLSession.shared.dataTask(with: request) { _, _, error in
            completion(error)
        }.resume()
    }
    
    
    
    // ------------------ PROFILE STATS ENDPOINTS ------------------ //
    func fetchWastedStats(userID: String, completion: @escaping (Result<[WastedItemStat], Error>) -> Void) {
        guard let url = URL(string: "http://192.168.1.185:8000/wasted_items/\(userID)") else {
            completion(.failure(NSError(domain: "Invalid URL", code: 400)))
            return
        }

        URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let data = data else {
                completion(.failure(NSError(domain: "No data", code: 500)))
                return
            }

            do {
                let stats = try JSONDecoder().decode([WastedItemStat].self, from: data)
                completion(.success(stats))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }

    
}
